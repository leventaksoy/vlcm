function [value] = where_is_partial(the_wanted,say_imp,the_partial)

value=0;

for i=1:say_imp
    if the_wanted==the_partial(i,1)
        value=i;
        break
    end
end
