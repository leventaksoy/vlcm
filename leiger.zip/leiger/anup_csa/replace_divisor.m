function [the_reps] = replace_divisor(the_index,the_frequency,the_partial,the_divisor,the_reps)

for i=1:the_frequency(the_index,1)
    say_occur=0;
    the_occurence=[];
    
    the_searched=the_reps{the_frequency(the_index,i+1),1};
    length_searched=length(the_searched);
    
    for j=1:length_searched
        the_searched(2,j)=0;
    end
    
    for j=1:1:length_searched-2
        if not(the_searched(2,j))
            carpan=the_searched(1,j)/the_divisor(1,1);
            [the_power,the_posodd] = make_number_posodd(carpan);
            
            if (the_posodd == 1) 
                mul_divisor=carpan*the_divisor;
                first_konum=j;
                
                second_konum=0;
                for k=first_konum+1:1:length_searched-1
                    if not(the_searched(2,k))
                        if the_searched(1,k)==mul_divisor(1,2)
                            second_konum=k;
                            break
                        end
                    end
                end
                
                third_konum=0;
                if second_konum
                    for k=second_konum+1:1:length_searched
                        if not(the_searched(2,k))
                            if the_searched(1,k)==mul_divisor(1,3)
                                third_konum=k;
                                break
                            end
                        end
                    end
                    
                    if third_konum
                        say_occur=say_occur+1;
                        the_occurence(say_occur,1)=third_konum;
                        the_occurence(say_occur,2)=carpan;
                        
                        the_searched(2,first_konum)=say_occur;
                        the_searched(2,second_konum)=say_occur;
                        the_searched(2,third_konum)=say_occur;
                    end
                end
            end
        end
    end

    new_rep=[];
    say_terms=0;

    for j=1:length_searched
        if the_searched(2,j)==0
            say_terms=say_terms+1;
            new_rep(1,say_terms)=the_searched(1,j);
        else
            if the_occurence(the_searched(2,j),1)==j
                say_terms=say_terms+1;
                new_rep(1,say_terms)=the_occurence(the_searched(2,j),2)*the_partial;

                say_terms=say_terms+1;
                new_rep(1,say_terms)=the_occurence(the_searched(2,j),2)*the_partial;
            end
        end
    end
    
    the_reps{the_frequency(the_index,i+1),1}=new_rep;
end