function [value] = is_inside_coef(aranan,yer_say,yer)

value=0;

for i=yer_say:-1:1
    if yer(i,1)==aranan
        value=1;
        return
    end
end

