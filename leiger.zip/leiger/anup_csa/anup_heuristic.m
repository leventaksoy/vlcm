clear;

file_coef=input('Enter the filename where the filter coefficients exist: ','s');
the_choice=input('Choose the type of number representation: (0:binary, 1:CSD): ');

initial_time=cputime;

file_name='';
dot_point=length(file_coef);
for i=length(file_coef):-1:1
    if file_coef(1,i)=='.'
        dot_point=i-1;
        break
    end
end
file_name=file_tmcm(1:1,1:dot_point);

file_result=[file_name,'.result'];
fid_result=fopen(file_result,'w');

fprintf(fid_result,'* CSA Implementation of Constant Coefficients\n');
saat=clock;
fprintf(fid_result,'* Date: %s Time: %d:%d:%.0f \n',date,saat(1,4),saat(1,5),saat(1,6));
fprintf(fid_result,'* Coefficient File: %s\n',file_coef);

fprintf(fid_result,'\n');
fprintf(fid_result,'*** Implementation of Coefficients ***\n');
fprintf(fid_result,'\n');

say_list=0;
coef_list=[];
fid_coef=fopen(file_coef,'r');

while 1
    the_line=fgetl(fid_coef);
    if the_line==-1
        break
    else
        if not(isempty(the_line))
            the_number=str2num(char(the_line));
            if the_number~=0
                [power,posodd_number]=make_number_posodd(the_number);
                if not(is_inside_coef(posodd_number,say_list,coef_list))
                    say_list=say_list+1;
                    coef_list(say_list,1)=posodd_number;
                end
                
                if the_number<0
                    fprintf(fid_result,'%d = -%d<<%d\n',the_number,posodd_number,power);
                else
                    fprintf(fid_result,'%d = +%d<<%d\n',the_number,posodd_number,power);
                end
            end
        end
    end
end

fclose(fid_coef);

say_imp=0;
the_imp=[];
the_partial=[];

say_divisors=0;
the_divisors=[];
the_frequency=[];

the_reps=cell(1,1);

for i=1:say_list
    if the_choice
        [say_instances,count_nonzero,cell_nonzero]=workon_csd_representation(coef_list(i,1));
    else
        [say_instances,count_nonzero,cell_nonzero]=workon_binary_representation(coef_list(i,1));
    end
    
    the_reps(i,1)=cell_nonzero;
    
    if count_nonzero>2
        coef_list(i,2)=0;
        [say_divisors,the_divisors,the_frequency]=find_nonoverlap_divisors(say_divisors,the_divisors,the_frequency,i,cell_nonzero{1,1});
    else
        coef_list(i,2)=1;
        say_imp=say_imp+1;
        the_partial(say_imp,1)=coef_list(i,1);
        for j=1:count_nonzero
            the_imp(say_imp,j)=cell_nonzero{1,1}(1,j);
        end
    end
end

max_occur=1;
max_occur_index=0;

for i=1:say_divisors
    if the_frequency(i,1)>max_occur
        if self_test(the_divisors(i,:))
            max_occur=the_frequency(i,1);
            max_occur_index=i;
        end
    end
end

while max_occur_index
    say_imp=say_imp+1;
    for i=1:3
        the_imp(say_imp,i)=the_divisors(max_occur_index,i);
    end
    
    the_partial(say_imp,1)=find_partial_value(the_divisors(max_occur_index,:));
    [the_reps]=replace_divisor(max_occur_index,the_frequency,the_partial(say_imp,1),the_divisors(max_occur_index,:),the_reps);
    
    say_divisors=0;
    the_divisors=[];
    the_frequency=[];
    
    for i=1:say_list
        if not(coef_list(i,2))
            the_rep=the_reps{i,1};
            if length(the_rep)>2
                [say_divisors,the_divisors,the_frequency]=find_nonoverlap_divisors(say_divisors,the_divisors,the_frequency,i,the_rep);
            else
                coef_list(i,2)=1;
            end
        end
    end
    
    max_occur=1;
    max_occur_index=0;
    
    for i=1:say_divisors
        if the_frequency(i,1)>max_occur
            if self_test(the_divisors(i,:))
                max_occur=the_frequency(i,1);
                max_occur_index=i;
            end
        end
    end    
end

fprintf(fid_result,'\n');
fprintf(fid_result,'*** Implenetations of Partial Terms ***\n');
fprintf(fid_result,'\n');

say_oper=0;
for i=1:say_imp
    no_oper=0;
    one_found=0;
    fprintf(fid_result,'S&C_%d =',the_partial(i,1));
    for j=1:3
        if the_imp(i,j)
            [power,posodd_number]=make_number_posodd(the_imp(i,j));
            
            if posodd_number==1
                if the_imp(i,j)<0
                    fprintf(fid_result,' -%d<<%d',posodd_number,power);
                else
                    fprintf(fid_result,' +%d<<%d',posodd_number,power);
                end
            else
                if not(one_found)
                    one_found=1;
                    if the_imp(i,j)<0
                        fprintf(fid_result,' -S%d<<%d',posodd_number,power);
                    else
                        fprintf(fid_result,' +S%d<<%d',posodd_number,power);
                    end
                else
                    if the_imp(i,j)<0
                        fprintf(fid_result,' -C%d<<%d',posodd_number,power);
                    else
                        fprintf(fid_result,' +C%d<<%d',posodd_number,power);
                    end
                end
            end
            
            the_imp(i,j)=posodd_number;
        else
            no_oper=1;
        end
    end
    
    fprintf(fid_result,'\n');
    
    if not(no_oper)
        say_oper=say_oper+1;
    end
end

say_intermediate=0;

for i=1:say_list
    the_comb=the_reps{i,1};
    
    if length(the_comb)>2
        the_comb=determine_partials(the_comb);
        
        devam=1;
        while devam
            size_comb=size(the_comb);
            
            if size_comb(1,2)==3
                devam=0;
                say_imp=say_imp+1;
                say_oper=say_oper+1;
                the_partial(say_imp,1)=coef_list(i,1);
                
                fprintf(fid_result,'S&C_%d =',coef_list(i,1));
                
                for j=1:3
                    is_intermediate=0;
                    
                    if and(the_comb(1,j)>0,the_comb(1,j)<1)
                        is_intermediate=1;
                    else
                        [power,posodd_number]=make_number_posodd(the_comb(1,j));
                    end
                    
                    if not(is_intermediate)
                        if the_comb(1,j)<0
                            if the_comb(2,j)==1
                                fprintf(fid_result,' -S%d<<%d',posodd_number,power);
                            elseif the_comb(2,j)==2
                                fprintf(fid_result,' -C%d<<%d',posodd_number,power);
                            else
                                fprintf(fid_result,' -%d<<%d',posodd_number,power);
                            end
                        else
                            if the_comb(2,j)==1
                                fprintf(fid_result,' +S%d<<%d',posodd_number,power);
                            elseif the_comb(2,j)==2
                                fprintf(fid_result,' +C%d<<%d',posodd_number,power);
                            else
                                fprintf(fid_result,' +%d<<%d',posodd_number,power);
                            end
                        end
                        the_imp(say_imp,j)=posodd_number;
                    else
                        if the_comb(1,j)<0
                            if the_comb(2,j)==1
                                fprintf(fid_result,' -Sint_%.0f<<%d',the_comb(1,j)*1000,0);
                            elseif the_comb(2,j)==2
                                fprintf(fid_result,' -Cint_%.0f<<%d',the_comb(1,j)*1000,0);
                            end
                        else
                            if the_comb(2,j)==1
                                fprintf(fid_result,' +Sint_%.0f<<%d',the_comb(1,j)*1000,0);
                            elseif the_comb(2,j)==2
                                fprintf(fid_result,' +Cint_%.0f<<%d',the_comb(1,j)*1000,0);
                            end
                        end
                        the_imp(say_imp,j)=the_comb(1,j);
                    end
                end
                fprintf(fid_result,'\n');
            else
                say_imp=say_imp+1;
                say_oper=say_oper+1;
                say_intermediate=say_intermediate+0.001;
                the_partial(say_imp,1)=say_intermediate;
                fprintf(fid_result,'S&Cint_%.0f =',say_intermediate*1000);
                
                for j=1:3
                    is_intermediate=0;
                    
                    if and(the_comb(1,j)>0,the_comb(1,j)<1)
                        is_intermediate=1;
                    else
                        [power,posodd_number]=make_number_posodd(the_comb(1,j));
                    end
                    
                    if not(is_intermediate)
                        if the_comb(1,j)<0
                            if the_comb(2,j)==1
                                fprintf(fid_result,' -S%d<<%d',posodd_number,power);
                            elseif the_comb(2,j)==2
                                fprintf(fid_result,' -C%d<<%d',posodd_number,power);
                            else
                                fprintf(fid_result,' -%d<<%d',posodd_number,power);
                            end
                        else
                            if the_comb(2,j)==1
                                fprintf(fid_result,' +S%d<<%d',posodd_number,power);
                            elseif the_comb(2,j)==2
                                fprintf(fid_result,' +C%d<<%d',posodd_number,power);
                            else
                                fprintf(fid_result,' +%d<<%d',posodd_number,power);
                            end
                        end
                        the_imp(say_imp,j)=posodd_number;
                    else
                        if the_comb(1,j)<0
                            if the_comb(2,j)==1
                                fprintf(fid_result,' -Sint_%.0f<<%d',the_comb(1,j)*1000,0);
                            elseif the_comb(2,j)==2
                                fprintf(fid_result,' -Cint_%.0f<<%d',the_comb(1,j)*1000,0);
                            end
                        else
                            if the_comb(2,j)==1
                                fprintf(fid_result,' +Sint_%.0f<<%d',the_comb(1,j)*1000,0);
                            elseif the_comb(2,j)==2
                                fprintf(fid_result,' +Cint_%.0f<<%d',the_comb(1,j)*1000,0);
                            end
                        end
                        the_imp(say_imp,j)=the_comb(1,j);
                    end
                end
                fprintf(fid_result,'\n');
                
                the_comb(:,1)=[];
                the_comb(1,1)=say_intermediate;
                the_comb(1,2)=say_intermediate;
                the_comb(2,1)=1;
                the_comb(2,2)=2;
            end
        end
    end
end

[max_level]=find_level(say_imp,the_imp,the_partial);

fprintf(fid_result,'\n');
fprintf(fid_result,'Number of CSAs: %d\n',say_oper);
fprintf(fid_result,'Number of adder-steps: %d\n',max_level);
fprintf(fid_result,'Required CPU time: %.2f\n',cputime-initial_time);
fprintf(fid_result,'\n');

fclose(fid_result);

fprintf('\n');
fprintf('Number of CSAs: %d\n',say_oper);
fprintf('Number of adder-steps: %d\n',max_level);
fprintf('Required CPU time: %.2f\n',cputime-initial_time);
fprintf('\n');
