function [partial_value] = find_partial_value(the_divisor)

one_found=0;
partial_value=0;

for i=1:3
    [power,the_number]=make_number_posodd(the_divisor(1,i));
    
    if the_number==1
        partial_value=partial_value+the_divisor(1,i);
    else
        if not(one_found)
            one_found=1;
            partial_value=partial_value+the_divisor(1,i);
        end
    end
end
