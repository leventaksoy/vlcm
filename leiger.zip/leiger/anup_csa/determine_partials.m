function the_comb = determine_partials(the_comb)

say_terms=0;
while say_terms~=length(the_comb)
    say_terms=say_terms+1;
    [power,posodd_number]=make_number_posodd(the_comb(1,say_terms));
    
    if posodd_number~=1
        the_comb(2,say_terms)=1;
        say_terms=say_terms+1;
        the_comb(2,say_terms)=2;
    else
        the_comb(2,say_terms)=0;
    end
end