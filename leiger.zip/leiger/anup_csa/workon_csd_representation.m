function [say_instances,count_nonzero,cell_nonzero] = workon_csd_representation(the_number)

say_instances=0;
count_nonzero=[];
cell_nonzero=cell(1,1);

[say_nonzero,non_zero]=find_csd_representation(the_number);

say_instances=say_instances+1;
count_nonzero(say_instances,1)=say_nonzero;
cell_nonzero{say_instances,1}=non_zero;
