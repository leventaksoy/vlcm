function [max_level] = find_level(say_imp,the_imp,the_partial)

all_found=0;
max_level=0;

for i=1:say_imp
    the_partial(i,2)=0;
end

while not(all_found)
    all_found=1;
    
    for i=1:say_imp
        if the_partial(i,2)==0
            the_level=0;
            level_found=1;
            
            for j=1:3
                if the_imp(i,j)~=0
                    if the_imp(i,j)~=1
                        the_pos=where_is_partial(the_imp(i,j),say_imp,the_partial);
                        
                        if the_partial(the_pos,2)~=0
                            if the_partial(the_pos,2)>the_level
                                the_level=the_partial(the_pos,2);
                            end
                        else
                            level_found=0;
                            break
                        end
                    end
                end
            end
            
            if level_found
                the_partial(i,2)=the_level+1;
                
                if the_partial(i,2)>max_level
                    max_level=the_partial(i,2);
                end
            else
                all_found=0;
            end
        end
    end
end


