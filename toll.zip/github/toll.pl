#!/usr/bin/perl

use strict;
use POSIX();
use warnings;
use Cwd qw(cwd); 
#use diagnostics;
#use Math::Matrix;
use Storable qw(dclone);
use Time::HiRes qw(time);
use Term::ANSIColor qw(:constants);

my $arg_ok = 1;
my $arg_cnt = 0;

my $mcm_algo = "exact";
my $ses_tech = "auto";
my $cse_aim = "width";
my $sle_aim = "area";
my $mcm_aim = "oper";
my $no_test = 10000;
my $dfs_time = 100;
my $coef_file = "";
my $is_signed = 0;
my $in_width = 16;
my $the_arch = 1;
my $the_verb = 2;
my $par_tech = 0;
my $dig_par = 1;

while (1){
  if (defined $ARGV[$arg_cnt]){
    if ($ARGV[$arg_cnt] eq "-h" or $ARGV[$arg_cnt] eq "-help"){
      $arg_ok = 0;
    }
    else {
      if (index($ARGV[$arg_cnt], "-f=") != -1){
        $coef_file = substr($ARGV[$arg_cnt], 3, length($ARGV[$arg_cnt])-3);
      }
      elsif (index($ARGV[$arg_cnt], "-a=") != -1){
        $the_arch = substr($ARGV[$arg_cnt], 3, length($ARGV[$arg_cnt])-3) + 0;
        if ($the_arch < 0 or $the_arch > 1){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-d=") != -1){
        $dig_par = substr($ARGV[$arg_cnt], 3, length($ARGV[$arg_cnt])-3) + 0;
        if ($dig_par < 1 or $dig_par > 7){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-t=") != -1){
        $par_tech = substr($ARGV[$arg_cnt], 3, length($ARGV[$arg_cnt])-3) + 0;
        if ($par_tech < 0 or $par_tech > 1){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-iw=") != -1){
        $in_width = substr($ARGV[$arg_cnt], 4, length($ARGV[$arg_cnt])-4) + 0;
        if ($in_width < 1){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-mcma=") != -1){
        $mcm_algo = substr($ARGV[$arg_cnt], 6, length($ARGV[$arg_cnt])-6);
        if ($mcm_algo ne "exact" and $mcm_algo ne "hcub"){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-amcm=") != -1){
        $mcm_aim = substr($ARGV[$arg_cnt], 6, length($ARGV[$arg_cnt])-6);
        if ($mcm_aim ne "oper" and $mcm_aim ne "step"){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-dfst=") != -1){
        $dfs_time = substr($ARGV[$arg_cnt], 6, length($ARGV[$arg_cnt])-6) + 0;
        if ($dfs_time < 1){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-ses=") != -1){
        $ses_tech = substr($ARGV[$arg_cnt], 5, length($ARGV[$arg_cnt])-5);
        if ($ses_tech ne "single" and $ses_tech ne "all" and $ses_tech ne "auto"){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-acse=") != -1){
        $cse_aim = substr($ARGV[$arg_cnt], 6, length($ARGV[$arg_cnt])-6);
        if ($cse_aim ne "width" and $cse_aim ne "step"){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-asle=") != -1){
        $sle_aim = substr($ARGV[$arg_cnt], 6, length($ARGV[$arg_cnt])-6);
        if ($sle_aim ne "area" and $sle_aim ne "delay"){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-not=") != -1){
        $no_test = substr($ARGV[$arg_cnt], 5, length($ARGV[$arg_cnt])-5) + 0;
        if ($no_test < 1){
          $arg_ok = 0;
        }
      }
      elsif (index($ARGV[$arg_cnt], "-signed") != -1){
        $is_signed = 1;
      }
      elsif (index($ARGV[$arg_cnt], "-v=") != -1){
        $the_verb = substr($ARGV[$arg_cnt], 3, length($ARGV[$arg_cnt])-3) + 0;
        if ($the_verb < 0 or $the_verb > 2){
          $arg_ok = 0;
        }
      }
      else{
        $arg_ok = 0;
      }
    }
  }
  else{
    last;
  }

  $arg_cnt++;
}

if ($arg_ok == 0){
  help_part();
}
else{
  if ($coef_file ne ""){
    if (($dig_par <= 4 and $mcm_algo eq "exact") or ($dig_par <= 7 and $mcm_algo eq "hcub")){
      main_part($coef_file);
    }
    else{
      help_part();
    }
  }
  else{
    help_part();
  }
}

sub help_part{
  print "##################################################################################################################################################################################################################################### \n";
  print "# Usage:       perl toll.pl -f=<FileName> -a=0/1 -d=1-7 -t=0/1 -iw=<int> -mcma=exact/hcub -amcm=oper/step -dfst=<int> -ses=single/all/auto -acse=width/step -asle=area/delay -not=<int> -signed -v=0/1/2 -h                         # \n";
  print "# f:           Name of the file including large constant(s)                                                                                                                                                                         # \n";
  print "# iw:          Bitwidth of the input variable by default it is 16                                                                                                                                                                   # \n";
  print "# a:           Architecture of the large constant multiplication block by default it is 1                                                                                                                                           # \n";
  print "#                0: Using a generic constant multiplier                                                                                                                                                                             # \n";
  print "#                1: Using a shift-adds architecture                                                                                                                                                                                 # \n";
  print "# d:           Number of hexadecimal digits to be used in partitioning of constants (when a is 1) by default it is 1                                                                                                                # \n";
  print "# t:           Partitioning strategy (when a is 1) by default it is 0                                                                                                                                                               # \n";
  print "#                0: Starting from the least significant digit and partition using d digits (strict)                                                                                                                                 # \n";
  print "#                1: Increasing the common digit patterns when d is greater than 1 (common digit)                                                                                                                                    # \n";
  print "# mcma:        MCM algorithm (when a is 1) by default it is our exact algorithm                                                                                                                                                     # \n";
  print "# amcm:        Aim in the MCM algorithm (when a is 1) by default it is the minimization of the number of operations                                                                                                                 # \n";
  print "# dfst:        Run time limit for the exact depth-first search MCM algorithm (when a is 1) by default it is 100 seconds                                                                                                             # \n";
  print "# ses:         Subexpression elimination strategy (when a is 1) by default it is auto                                                                                                                                               # \n";
  print "#                single: replaces one subexpression at each iteration                                                                                                                                                               # \n";
  print "#                all: replaces all possible subexpressions at each iteration                                                                                                                                                        # \n";
  print "#                auto: chooses in between single and all based on the number of operands                                                                                                                                            # \n";
  print "# acse:        Aim in the elimination of subexpressions (when a is 1) by default it is the minimization of width                                                                                                                    # \n";
  print "# asle:        Aim in the synthesis of linear equations (when a is 1) by default it is the minimization of area                                                                                                                     # \n";
  print "# not:         Number of test patterns by default it is 10000                                                                                                                                                                       # \n";
  print "# signed:      Considers that the input is a signed variable by default it does not                                                                                                                                                 # \n";
  print "# v:           Verbosity level by default it is 2 meaning full                                                                                                                                                                      # \n";
  print "# h:           Prints this page                                                                                                                                                                                                     # \n";
  print "# Description: This code realizes the multiplication of large constant(s) by an input variable under the shift-adds architecture and generates the design and testbench files in Verilog                                            # \n";
  print "# Notes:       Constants should be given in hexadecimal format starting with 0x                                                                                                                                                     # \n";
  print "#              Aim in the MCM algorithm can be the minimization of the number of adders/substractors (oper) or the minimization of the number of adders/subtractors under the minimum number of adder-steps (step)                  # \n";
  print "#              Aim in the elimination of subexpressions is always to eliminate the most common one, width option chooses the one with the smallest bit-width and step option chooses the one with the minimum number of adder-steps # \n";
  print "#              Aim in the synthesis of linear equations can be the minimization of area (area) or the minimization of delay (delay)                                                                                                 # \n";
  print "#              Maximum value of d can be 4 and 7 for the exact and hcub algorithms, respectively                                                                                                                                    # \n";
  print "# Examples:    perl lcm.pl -f=examples/example.txt -a=0                                                                                                                                                                             # \n";
  print "#              perl lcm.pl -f=examples/example.txt -a=1 -d=4 -t=1 -iw=8 -mcma=hcub -amcm=step -acse=step -asle=delay                                                                                                                # \n";
  print "##################################################################################################################################################################################################################################### \n";
}

sub skip_spaces_forward{
  my ($the_string, $the_offset) = @_;
  my $the_length = length($the_string);

  while (index($the_string, " ", $the_offset) eq $the_offset) {
    $the_offset++;
    if ($the_offset > $the_length) {
      last;
    }
  }

  return $the_offset;
}

sub skip_spaces_backward{
  my ($the_string, $the_offset) = @_;

  while (index($the_string, " ", $the_offset) eq $the_offset) {
    $the_offset--;
    if ($the_offset < 0) {
      last;
    }
  }

  return $the_offset;
}

sub is_inside_string_array{
  my ($the_element, $the_cnt, $the_arr_ref) = @_;

  my $le = length($the_element);

  for (my $i = 0; $i < $the_cnt; $i++){
    if ($le == length($the_arr_ref->[$i])){
      if ($the_arr_ref->[$i] eq $the_element){
        return ($i);
      }
    }
  }

  return (-1);
}

sub is_inside_numeric_array{
  my ($the_element, $the_cnt, $the_arr_ref) = @_;

  for (my $i = 0; $i < $the_cnt; $i++){
    if ($the_arr_ref->[$i] == $the_element){
      return ($i);
    }
  }

  return (-1);
}

sub max_find2{
  my ($the_first, $the_second) = @_;

  if ($the_first >= $the_second){
    return ($the_first);
  }
  else{
    return ($the_second);
  }
}

sub min_find2{
  my ($the_first, $the_second) = @_;

  if ($the_first <= $the_second){
    return ($the_first);
  }
  else{
    return ($the_second);
  }
}

sub make_number_posodd{
  my ($the_num) = @_;

  my $the_sign = 0;
  my $the_shift = 0;

  if ($the_num){
    if ($the_num < 0){
      $the_num = (-1)*$the_num;
      $the_sign = 1;
    }

    while (($the_num % 2) == 0){
      $the_num = $the_num/2;
      $the_shift++;
    }
  }

  return ($the_sign, $the_shift, $the_num);
}

sub is_array_inside_matrix{
  my ($the_length, $arr_ref, $the_cnt, $mat_ref) = @_;

  for (my $i=0; $i<$the_cnt; $i++){
    my $is_same = 1;
    for (my $j=0; $j<$the_length; $j++){
      if ($arr_ref->[$j] != $mat_ref->[$i][$j]){
        $is_same = 0;
        last;
      }
    }

    if ($is_same){
      return ($i);
    }
  }

  return (-1);
}

sub does_subexp_overlap{
  my ($pos_coef, $pos_one, $pos_two, $the_ind, $the_mat_ref) = @_;

  for (my $i=0; $i<$the_mat_ref->[$the_ind][5]; $i++){
    if ($the_mat_ref->[$the_ind][3*($i+2)] == $pos_coef){
      if ($the_mat_ref->[$the_ind][3*($i+2)+1] == $pos_one or $the_mat_ref->[$the_ind][3*($i+2)+1] == $pos_two){
        return (1);
      }
      elsif ($the_mat_ref->[$the_ind][3*($i+2)+2] == $pos_one or $the_mat_ref->[$the_ind][3*($i+2)+2] == $pos_two){
        return (1);
      }
    }
  }

  return (0);
}

sub print_array{
  my ($the_label, $the_cnt, $the_arr_ref) = @_;

  print "$the_label: ";
  for (my $i = 0; $i < $the_cnt; $i++){
    print "$the_arr_ref->[$i] ";
  }
  print "\n";
}

sub print_matrix{
  my ($the_label, $the_row, $the_col, $the_mat_ref) = @_;

  print "$the_label: \n";
  for (my $i = 0; $i < $the_row; $i++){
    for (my $j = 0; $j < $the_col; $j++){
      print "$the_mat_ref->[$i][$j] ";
    }
    print "\n";
  }
}

sub print_matrix_ttexp{
  my ($the_label, $the_row, $the_mat_ref) = @_;

  print "$the_label: \n";
  for (my $i = 0; $i < $the_row; $i++){
    for (my $j = 0; $j < 5; $j++){
      print "$the_mat_ref->[$i][$j] ";
    }
    print "$the_mat_ref->[$i][5] ";
    for (my $j = 0; $j < $the_mat_ref->[$i][5]; $j++){
      print "$the_mat_ref->[$i][3*($j+2)] $the_mat_ref->[$i][3*($j+2)+1] $the_mat_ref->[$i][3*($j+2)+2] ";
    }
    print "\n";
  }
}

sub print_ref_arr{
  my ($the_label, $the_cnt, $num_arr_ref, $ref_arr_ref) = @_;

  print "$the_label: \n";
  for (my $i=0; $i<$the_cnt; $i++){
    for (my $j=0; $j<$num_arr_ref->[$i]; $j++){
      print "$ref_arr_ref->[$i]->[$j] ";
    }
    print "\n";
  }
}

sub print_irregular_mat{
  my ($the_label, $the_cnt, $cnt_arr_ref, $mat_ref) = @_;

  print "$the_label: \n";
  for (my $i=0; $i<$the_cnt; $i++){
    for (my $j=0; $j<$cnt_arr_ref->[$i]; $j++){
      print "$mat_ref->[$i][$j] ";
    }
    print "\n";
  }
}


sub find_backforward_slash{
  my ($the_string) = @_;

  my $is_bfs = -1;

  if (index($the_string, "/") != -1){
    $is_bfs = 1;
  }
  elsif (index($the_string, "\\") != -1){
    $is_bfs = 0
  }

  return ($is_bfs);
}

sub extract_file_name_directory{
  my ($the_file) = @_;

  my ($file_name, $file_dir) = "";
  my $the_cwd = cwd;

  #Find the bfs in the current working directory
  my $is_bfs = find_backforward_slash($the_cwd);

  ##Extract the file name and directory
  my $the_index = length($the_file);
  while (substr($the_file, $the_index, 1) ne "." and substr($the_file, $the_index, 1) ne "\\" and substr($the_file, $the_index, 1) ne "/"){
    $the_index--;

    if ($the_index < 0){
      last;
    }
  }
  if ($the_index <= 0){
    $file_name = $the_file;
    $file_dir = $the_cwd;
    if ($is_bfs == 0){ $file_dir .= "\\";}else{$file_dir .= "/";}
  }
  elsif (substr($the_file, $the_index, 1) eq "\\" or substr($the_file, $the_index, 1) eq "/"){
    $file_name = substr($the_file, $the_index+1, length($the_file)-$the_index);
    $file_dir = substr($the_file, 0, $the_index+1);
  }
  else{
    $the_index--;
    my $init_index = $the_index;
    while (substr($the_file, $init_index, 1) ne "\\" and substr($the_file, $init_index, 1) ne "/"){
      $init_index--;

      if ($init_index < 0){
        last;
      }
    }

    $file_name = substr($the_file, $init_index+1, $the_index-$init_index);

    if ($init_index<0){
      $file_dir = $the_cwd;
      if ($is_bfs == 0){ $file_dir .= "\\";}else{$file_dir .= "/";}
    }
    else{
      $file_dir = substr($the_file, 0, $init_index+1);
    }
  }

  return ($file_name, $file_dir);
}

sub hex2bin{
  my ($coef_width, $coef_arr_ref) = @_;

  my $coef_bin_width = 4*$coef_width;
  my @coef_bin_arr = ();

  for (my $i=0; $i<$coef_width; $i++){
    if ($coef_arr_ref->[$i] eq "0"){
      $coef_bin_arr[4*$i] = 0; $coef_bin_arr[4*$i+1] = 0; $coef_bin_arr[4*$i+2] = 0; $coef_bin_arr[4*$i+3] = 0;
    }
    elsif ($coef_arr_ref->[$i] eq "1"){
      $coef_bin_arr[4*$i] = 1; $coef_bin_arr[4*$i+1] = 0; $coef_bin_arr[4*$i+2] = 0; $coef_bin_arr[4*$i+3] = 0;
    }
    elsif ($coef_arr_ref->[$i] eq "2"){
      $coef_bin_arr[4*$i] = 0; $coef_bin_arr[4*$i+1] = 1; $coef_bin_arr[4*$i+2] = 0; $coef_bin_arr[4*$i+3] = 0;
    }
    elsif ($coef_arr_ref->[$i] eq "3"){
      $coef_bin_arr[4*$i] = 1; $coef_bin_arr[4*$i+1] = 1; $coef_bin_arr[4*$i+2] = 0; $coef_bin_arr[4*$i+3] = 0;
    }
    elsif ($coef_arr_ref->[$i] eq "4"){
      $coef_bin_arr[4*$i] = 0; $coef_bin_arr[4*$i+1] = 0; $coef_bin_arr[4*$i+2] = 1; $coef_bin_arr[4*$i+3] = 0;
    }
    elsif ($coef_arr_ref->[$i] eq "5"){
      $coef_bin_arr[4*$i] = 1; $coef_bin_arr[4*$i+1] = 0; $coef_bin_arr[4*$i+2] = 1; $coef_bin_arr[4*$i+3] = 0;
    }
    elsif ($coef_arr_ref->[$i] eq "6"){
      $coef_bin_arr[4*$i] = 0; $coef_bin_arr[4*$i+1] = 1; $coef_bin_arr[4*$i+2] = 1; $coef_bin_arr[4*$i+3] = 0;
    }
    elsif ($coef_arr_ref->[$i] eq "7"){
      $coef_bin_arr[4*$i] = 1; $coef_bin_arr[4*$i+1] = 1; $coef_bin_arr[4*$i+2] = 1; $coef_bin_arr[4*$i+3] = 0;
    }
    elsif ($coef_arr_ref->[$i] eq "8"){
      $coef_bin_arr[4*$i] = 0; $coef_bin_arr[4*$i+1] = 0; $coef_bin_arr[4*$i+2] = 0; $coef_bin_arr[4*$i+3] = 1;
    }
    elsif ($coef_arr_ref->[$i] eq "9"){
      $coef_bin_arr[4*$i] = 1; $coef_bin_arr[4*$i+1] = 0; $coef_bin_arr[4*$i+2] = 0; $coef_bin_arr[4*$i+3] = 1;
    }
    elsif ($coef_arr_ref->[$i] eq "A" or $coef_arr_ref->[$i] eq "a"){
      $coef_bin_arr[4*$i] = 0; $coef_bin_arr[4*$i+1] = 1; $coef_bin_arr[4*$i+2] = 0; $coef_bin_arr[4*$i+3] = 1;
    }
    elsif ($coef_arr_ref->[$i] eq "B" or $coef_arr_ref->[$i] eq "b"){
      $coef_bin_arr[4*$i] = 1; $coef_bin_arr[4*$i+1] = 1; $coef_bin_arr[4*$i+2] = 0; $coef_bin_arr[4*$i+3] = 1;
    }
    elsif ($coef_arr_ref->[$i] eq "C" or $coef_arr_ref->[$i] eq "c"){
      $coef_bin_arr[4*$i] = 0; $coef_bin_arr[4*$i+1] = 0; $coef_bin_arr[4*$i+2] = 1; $coef_bin_arr[4*$i+3] = 1;
    }
    elsif ($coef_arr_ref->[$i] eq "D" or $coef_arr_ref->[$i] eq "d"){
      $coef_bin_arr[4*$i] = 1; $coef_bin_arr[4*$i+1] = 0; $coef_bin_arr[4*$i+2] = 1; $coef_bin_arr[4*$i+3] = 1;
    }
    elsif ($coef_arr_ref->[$i] eq "E" or $coef_arr_ref->[$i] eq "e"){
      $coef_bin_arr[4*$i] = 0; $coef_bin_arr[4*$i+1] = 1; $coef_bin_arr[4*$i+2] = 1; $coef_bin_arr[4*$i+3] = 1;
    }
    elsif ($coef_arr_ref->[$i] eq "F" or $coef_arr_ref->[$i] eq "f"){
      $coef_bin_arr[4*$i] = 1; $coef_bin_arr[4*$i+1] = 1; $coef_bin_arr[4*$i+2] = 1; $coef_bin_arr[4*$i+3] = 1;
    }
    else{
      print "[ERROR] The character $coef_arr_ref->[$i] is NOT a hexadecimal digit! \n";
      #sleep 10;
    }
  }

  return ($coef_bin_width, \@coef_bin_arr);
}

sub bin2hex{
  my ($out_width, $out_rep_ref) = @_;

  my $hex_dig = 0;
  my $hex_sum = 0;
  my @out_hex = ();
  my $hex_width = 0;

  for (my $i=0; $i<$out_width; $i++){
    if (($i+1) % 4 == 0 or $i == $out_width-1){
      $hex_sum += 2**($hex_dig)*$out_rep_ref->[$i];
      if ($hex_sum >= 0 and $hex_sum <= 9){
        $out_hex[$hex_width] = chr($hex_sum+48);
      }
      else{
        $out_hex[$hex_width] = chr($hex_sum+55);
      }
      $hex_width++;

      $hex_dig = 0;
      $hex_sum = 0;
    }
    else{
      $hex_sum += 2**($hex_dig)*$out_rep_ref->[$i];
      $hex_dig++;
    }
  }

  return ($hex_width, \@out_hex);
}

sub hex2dec{
  my ($the_hex) = @_;

  my $the_dec = 0;
  my $ascii_val = ord($the_hex);

  if ($ascii_val >= 48 and $ascii_val <= 57){
    $the_dec += ($ascii_val-48);
  }
  elsif ($ascii_val >= 65 and $ascii_val <= 70){
    $the_dec += ($ascii_val-55);
  }
  elsif ($ascii_val >= 97 and $ascii_val <= 102){
    $the_dec += ($ascii_val-87);
  }

  return ($the_dec);
}

sub hexterm2decimal{
  my ($the_term) = @_;

  my $dec_val = 0;

  for (my $i=0; $i<length($the_term); $i++){
    my $dec_char = hex2dec(substr($the_term, $i, 1));
    $dec_val += $dec_char*(16**$i);
  }
      
  return ($dec_val);
}

sub int2sign{
  my ($the_int, $the_len) = @_;

  my @the_rep = ();

  if ($the_int < 0){
    $the_int = 2**$the_len - abs($the_int);
  }

  foreach my $i (1 .. $the_len){
    $the_rep[$i] = 0;
  }

  my $the_index = 0;
  while ($the_int > 1){
    my $the_val = $the_int % 2;
    $the_rep[$the_index] = $the_val;
    $the_int = ($the_int - $the_val) / 2;
    $the_index++;
  }

  $the_rep[$the_index] = $the_int;

  return (\@the_rep);
}

sub read_coefs{
  my ($local_coef_file) = @_;

  my $coef_cnt = 0;
  my @coef_width_arr = ();
  my @zero_coef_arr = ();
  my @coef_ref_arr = ();

  my $the_char = "";
  my $the_width = 0;
  my $init_index = 0;
  my $last_index = 0;
  
  if ($the_verb > 0){print "[INFO] Reading the large constants... \n";}
  if (open (my $the_fid, '<:encoding(UTF-8)', $local_coef_file)){
    while (my $the_line = <$the_fid>){
      chomp ($the_line);
      my $lline = length($the_line);

      $init_index = skip_spaces_forward($the_line, 0);
      if ($init_index < $lline){
        if (substr($the_line, $init_index, 2) eq "0x"){
          $init_index += 2;
          $the_width = 0;
          my @the_array = ();
          my $zero_coef = 1;

          while (1){
            $the_char = substr($the_line, $init_index, 1);
            if ($the_char =~ /^[a-fA-F0-9]$/){
              unshift(@the_array, $the_char);
              $the_width++;
              if ($the_char ne "0"){
                $zero_coef = 0;
              }
            }
            else{
              if ($the_char ne " " and $the_char ne ""){
                print "[INFO] The character $the_char is NOT acceptable \n";
              }
            }

            $init_index++;
            if ($init_index > $lline){
              last;
            }
          }

          $zero_coef_arr[$coef_cnt] = $zero_coef;
          $coef_ref_arr[$coef_cnt] = \@the_array;
          $coef_width_arr[$coef_cnt] = $the_width;
          $coef_cnt++
        }
        else{
          print "[ERROR] The constant should be given in hexadecimal starting with 0x \n";
        }
      }
    }

    close ($the_fid);
  }
  else{
    print "[ERROR] Could not open the $coef_file file! \n";
  }

  return ($coef_cnt, \@coef_width_arr, \@coef_ref_arr, \@zero_coef_arr);
}

sub extract_paths{
  my ($paths_file, $search_phrase) = @_;

  my $paths_ok = 1;
  my $path_algo = " ";
  my $path_high2low = " ";

  my $algo_phrase = $search_phrase . "_algo";
  my $h2l_phrase = $search_phrase . "_high2low";

  if (-e $paths_file){
    my $the_index = 0;
    my $init_index = 0;
    my $last_index = 0;

    if (open (my $file_header, '<:encoding(UTF-8)', $paths_file)){
      while (my $the_line = <$file_header>){
        chomp $the_line;

        $the_index = index ($the_line, "=");

        if ($the_index >= 0){
          $init_index = skip_spaces_forward($the_line, 0);
          $last_index = skip_spaces_backward($the_line, $the_index-1);
          my $the_solver = substr($the_line, $init_index, $last_index-$init_index+1);

          $init_index = skip_spaces_forward($the_line, $the_index+1);
          $last_index = skip_spaces_backward($the_line, length($the_line));
          my $the_path = substr($the_line, $init_index, $last_index-$init_index+1);

          if ($the_path =~ /[0-9a-zA-Z_]/ ){
            if ($the_solver eq $algo_phrase){
              $path_algo = $the_path;
            }
            elsif ($the_solver eq $h2l_phrase){
              $path_high2low = $the_path;
            }
          }
          else{
            $paths_ok = 0;
          }
        }
      }

      if ($path_algo eq " "){
        $paths_ok = 0;
        print "[ERROR] Path to the optimization algorithm could not be extracted from the $paths_file file! \n";
      }
      if ($search_phrase eq "mcm" and $path_high2low eq " "){
        $paths_ok = 0;
        print "[ERROR] Path to the high2low algorithm could not be extracted from the $paths_file file! \n";
      }

      close ($file_header);
    }
    else{
      print "[ERROR] Could not open the $paths_file file! \n";
    }
  }
  else{
    $paths_ok = 0;
    print "[ERROR] Could not find the $paths_file file including paths to solvers! \n";
  }

  return ($paths_ok, $path_algo, $path_high2low);
}

sub extract_operand_step{
  my ($the_oper, $mcm_oper, $mcm_step_ref) = @_;

  my $the_step = -1;

  for (my $i=0; $i<$mcm_oper; $i++){
    if ($mcm_step_ref->[$i][0] == $the_oper){
      return ($mcm_step_ref->[$i][1]);
    }
  }

  return ($the_step);
}

sub extract_mcm_oper_hcub{
  my ($mcm_file) = @_;

  my $mcm_oper = 0;
  my $mcm_step = 0;
  my @mcm_step_mat = ();

  my $the_oper;
  my $the_char;
  
  my $init_index = 0;
  my $last_index = 0;

  if (open (my $the_fid, '<:encoding(UTF-8)', $mcm_file)){
    while (my $the_line = <$the_fid>){
      chomp ($the_line);
      my $lline = length($the_line);

      my $last_index = index($the_line, "=");
      if ($last_index != -1){
        $last_index = skip_spaces_backward($the_line, $last_index-1);
        $init_index = skip_spaces_forward($the_line, 0);
        $the_oper = substr($the_line, $init_index, $last_index-$init_index+1) + 0.0;
        
        $last_index = index($the_line, ")");
        if ($last_index != -1){
          my $dig_cnt = 0;
          my $the_step = 0;
          $last_index = skip_spaces_backward($the_line, $last_index-1);
          while (1){
            $the_char = substr($the_line, $last_index, 1);
            if ($the_char ne " " and $the_char ne ","){
              $the_step += (10**$dig_cnt)*($the_char + 0);
              $last_index--;
              $dig_cnt++;
            }
            else{
              last;
            }
          }
          $mcm_step_mat[$mcm_oper][0] = $the_oper;
          $mcm_step_mat[$mcm_oper][1] = $the_step;
          $mcm_oper++;

          if ($the_step > $mcm_step){
            $mcm_step = $the_step;
          }
        }
        else{
          print "[WARNING] There is somethimg wrong with the declaration of the operation $the_line! \n";
        }
      }
      else{
        last;
      }
    }

    close ($the_fid);
  }
  else{
    print "[ERROR] Could not open the $mcm_file file! \n";
  }

  return ($mcm_oper, $mcm_step, \@mcm_step_mat);
}

sub extract_mcm_oper_ours{
  my ($mcm_file) = @_;

  my @mcm_step_mat = ();
  my $mcm_oper = 0;

  my $the_end = 0;
  my $the_char = "";
  my $the_index = 0;
  my $init_index = 0;
  my $last_index = 0;

  my $oper_out = 0;
  my $step_one = 0;
  my $step_two = 0;
  my $oper_one = 0;
  my $oper_two = 0;
  
  if (open (my $the_fid, '<:encoding(UTF-8)', $mcm_file)){
    while (my $the_line = <$the_fid>){
      chomp ($the_line);
      my $lline = length($the_line);

      $init_index = index($the_line, "*** Implementation of Partial Terms ***");
      if ($init_index != -1){
        #The first carriage return
        $the_line = <$the_fid>;
        while (1){
          $the_line = <$the_fid>;

          $the_index = index($the_line, "=");
          if ($the_index != -1){
            #Operation output
            $last_index=skip_spaces_forward($the_line, 0);
            $oper_out = 0;
            while (1){
              $the_char = substr($the_line, $last_index, 1);
              if ($the_char eq ">"){
                last;
              }
              else{
                $oper_out = $oper_out*10 + $the_char + 0.0;
                $last_index++;
              }
            }

            #First operand
            $last_index = skip_spaces_forward($the_line, $the_index+1);
            $last_index++;
            $oper_one = 0;
            while (1){
              $the_char = substr($the_line, $last_index, 1);
              if ($the_char eq "<"){
                last;
              }
              else{
                $oper_one = $oper_one*10 + $the_char + 0.0;
                $last_index++;
              }
            }
            if ($oper_one == 1){
              $step_one = 0;
            }
            else{
              ($step_one) = extract_operand_step($oper_one, $mcm_oper, \@mcm_step_mat);
            }

            #Second operand
            while (substr($the_line, $last_index, 1) ne " "){
              $last_index++;
            }
            $last_index = skip_spaces_forward($the_line, $last_index);
            $last_index++;
            $oper_two = 0;
            while (1){
              $the_char = substr($the_line, $last_index, 1);
              if ($the_char eq "<"){
                last;
              }
              else{
                $oper_two = $oper_two*10 + $the_char + 0.0;
                $last_index++;
              }
            }
            if ($oper_two == 1){
              $step_two = 0;
            }
            else{
              ($step_two) = extract_operand_step($oper_two, $mcm_oper, \@mcm_step_mat);
            }

            if ($step_one == -1 or $step_two == -1){
              print "[ERROR] Could not determine the step of $oper_out! \n";
            }
            else{
              $mcm_step_mat[$mcm_oper][0] = $oper_out + 0.0;
              $mcm_step_mat[$mcm_oper][1] = max_find2($step_one, $step_two)+1;
              $mcm_oper++;
            }
          }
          else{
            $the_end = 1;
            last;
          }
        }
      }

      if ($the_end){
        last;
      }
    }
  }
  else{
    print "[ERROR] Could not find the $mcm_file file! \n";
  }

  return ($mcm_oper, \@mcm_step_mat);
}

sub extract_operations_hcub{
  my ($file_dir, $file_name) = @_;
  
  my $oper_cnt = 0;
  my @oper_mat = ();
  my @oper_def_arr = ();

  my $dig_cnt;
  my $the_char;
  my $the_out = 0;
  my $oper_one = 0;
  my $oper_two = 0;
  my $sign_one = 0;
  my $sign_two = 0;
  my $shift_one = 0;
  my $shift_two = 0;

  my $the_index = 0;
  my $last_index = 0;
  my $init_index = 0;

  my $mcm_file = $file_dir . $file_name . "_mcm.result";

  if (open (my $the_fid, '<:encoding(UTF-8)', $mcm_file)){
    while (my $the_line = <$the_fid>){
      chomp ($the_line);
      my $lline = length($the_line);

      my $the_index = index($the_line, "=");
      if ($the_index != -1){
        #THE OUTPUT
        $last_index = skip_spaces_backward($the_line, $the_index-1);
        $init_index = skip_spaces_forward($the_line, 0);
        $the_out = substr($the_line, $init_index, $last_index-$init_index+1) + 0.0;
        
        while (substr($the_line, $the_index, 1) ne "("){
          $the_index++;
          if ($the_index > $lline){
            last;
          }
        }
        
        if ($the_index < $lline){
          $the_index++;
          
          #THE OPERAND ONE
          $oper_one = 0;
          while (1){
            $the_char = substr($the_line, $the_index, 1);
            if ($the_char eq "," or $the_char eq " "){
              last;
            }
            else{
              $oper_one = $oper_one*10 + ($the_char + 0);
              $the_index++;
            }
          }

          $the_index = skip_spaces_forward($the_line, $the_index+1);

          #THE OPERAND TWO
          $oper_two = 0;
          while (1){
            $the_char = substr($the_line, $the_index, 1);
            if ($the_char eq "," or $the_char eq " "){
              last;
            }
            else{
              $oper_two = $oper_two*10 + ($the_char + 0);
              $the_index++;
            }
          }
          
          $the_index = skip_spaces_forward($the_line, $the_index+1);
          
          #THE SIGN and SHIFT ONE
          $sign_one = 0;
          if (substr($the_line, $the_index, 1) eq "-"){
            $sign_one = 1;
            $the_index++;
          }
          $shift_one = 0;
          while (1){
            $the_char = substr($the_line, $the_index, 1);
            if ($the_char eq "/" ){
              last;
            }
            else{
              $shift_one = $shift_one*10 + ($the_char + 0);
              $the_index++;
            }
          }

          $the_index++;
          
          #THE SIGN and SHIFT TWO
          $sign_two = 0;
          if (substr($the_line, $the_index, 1) eq "-"){
            $sign_two = 1;
            $the_index++;
          }
          $shift_two = 0;
          while (1){
            $the_char = substr($the_line, $the_index, 1);
            if ($the_char eq "," ){
              last;
            }
            else{
              $shift_two = $shift_two*10 + ($the_char + 0);
              $the_index++;
            }
          }

          $oper_mat[$oper_cnt][0] = $the_out;
          if (($shift_one == 1 and $shift_two > 1) or ($shift_one > 1 and $shift_two == 1)){
            $oper_mat[$oper_cnt][1] = 0;
          }
          else{
            my $the_result = ((-1)**$sign_one)*$oper_one*(2**($shift_one-1)) + ((-1)**$sign_two)*$oper_two*(2**($shift_two-1));
            my ($the_sign, $the_shift, $posodd_num)  = make_number_posodd($the_result);
            $oper_mat[$oper_cnt][1] = $the_shift;
            if ($the_out != $posodd_num){
              print "[ERROR] There is a miscalculation in the operation $the_line! \n";
            }
          }
          if ($sign_one){
            $oper_mat[$oper_cnt][2] = $sign_two;
            $oper_mat[$oper_cnt][3] = $oper_two;
            $oper_mat[$oper_cnt][4] = ($shift_two-1);
            $oper_mat[$oper_cnt][5] = $sign_one;
            $oper_mat[$oper_cnt][6] = $oper_one;
            $oper_mat[$oper_cnt][7] = ($shift_one-1);
          }
          else{
            $oper_mat[$oper_cnt][2] = $sign_one;
            $oper_mat[$oper_cnt][3] = $oper_one;
            $oper_mat[$oper_cnt][4] = ($shift_one-1);
            $oper_mat[$oper_cnt][5] = $sign_two;
            $oper_mat[$oper_cnt][6] = $oper_two;
            $oper_mat[$oper_cnt][7] = ($shift_two-1);
          }
          $oper_def_arr[$oper_cnt] = $the_line;
          $oper_cnt++;
        }
        else{
          print "[WARNING] There is something wrong with the operation $the_line! \n";
        }
      }
      else{
        last;
      }
    }

    close ($the_fid);
  }
  else{
    print "[ERROR] Could not open the $mcm_file file! \n";
  }

  return($oper_cnt, \@oper_mat, \@oper_def_arr);
}

sub generate_mcm_hcub_verilog{
  my ($file_dir, $file_name, $mcm_coef_cnt, $mcm_coef_arr_ref) = @_;

  my $the_width;
  my $signed_str = $is_signed ? "signed " : "";
  
  my $file_result = $file_dir . $file_name . "_mcm.result";
  my $file_verilog = $file_dir . $file_name . "_mcm.v";
  open (my $fid_ver, ">", $file_verilog);

  my $date_time = localtime();
  printf $fid_ver "// Shift-Adds Description of the MCM Block Obtained by Hcub in Verilog \n";
  printf $fid_ver "// Date: %s \n", $date_time;
  printf $fid_ver "// MCM File: %s \n", $file_result; 
  printf $fid_ver "\n"; 
  printf $fid_ver "module %s_mcm (", $file_name; 
  for (my $i=0; $i<$mcm_coef_cnt; $i++){
    if ($mcm_coef_arr_ref->[$i] < 0){
      printf $fid_ver "m%dx, ", abs($mcm_coef_arr_ref->[$i]);
    }
    else{
      printf $fid_ver "p%dx, ", $mcm_coef_arr_ref->[$i];
    }
  }
  printf $fid_ver "x1); \n";
  printf $fid_ver "\n"; 
  printf $fid_ver "// Declaration of IOs \n";
  printf $fid_ver "input %s[%d:0] x1; \n", $signed_str, $in_width-1;
  for (my $i=0; $i<$mcm_coef_cnt; $i++){
    if ($mcm_coef_arr_ref->[$i] < 0){
      $the_width = POSIX::floor(log(abs($mcm_coef_arr_ref->[$i])/log(2)))+1;
      printf $fid_ver "output %s[%d:0] m%dx; \n", $signed_str, $in_width+$the_width-1, abs($mcm_coef_arr_ref->[$i]);
    }
    else{
      $the_width = POSIX::ceil(log($mcm_coef_arr_ref->[$i])/log(2));
      printf $fid_ver "output %s[%d:0] p%dx; \n", $signed_str, $in_width+$the_width-1, $mcm_coef_arr_ref->[$i];
    }
  }
  printf $fid_ver "\n"; 
  printf $fid_ver "// Declaration of Wires \n";
  my ($oper_cnt, $oper_mat_ref, $oper_def_arr_ref) = extract_operations_hcub($file_dir, $file_name);
  for (my $i=0; $i<$oper_cnt; $i++){
    $the_width = POSIX::ceil(log($oper_mat_ref->[$i][0])/log(2));
    printf $fid_ver "wire %s[%d:0] x%d; \n", $signed_str, $in_width+$the_width-1, $oper_mat_ref->[$i][0];

    if ($oper_mat_ref->[$i][1]){
      printf $fid_ver "wire %s[%d:0] x%ds%d; \n", $signed_str, $in_width+$the_width+$oper_mat_ref->[$i][1]-1, $oper_mat_ref->[$i][0], $oper_mat_ref->[$i][1];
    }
  }
  printf $fid_ver "\n";
  printf $fid_ver "// Realization of Partial Terms \n";
  for (my $i=0; $i<$oper_cnt; $i++){
    printf $fid_ver "// %s \n", $oper_def_arr_ref->[$i];
    printf $fid_ver "assign x%d", $oper_mat_ref->[$i][0];
    if ($oper_mat_ref->[$i][1]){
      printf $fid_ver "s%d", $oper_mat_ref->[$i][1];
    }
    printf $fid_ver " = ((x%d", $oper_mat_ref->[$i][3];
    if ($oper_mat_ref->[$i][4]){
      printf $fid_ver "<<<%d", $oper_mat_ref->[$i][4];
    }
    printf $fid_ver ") ";
    if ($oper_mat_ref->[$i][5]){
      printf $fid_ver "- (x%d", $oper_mat_ref->[$i][6];
    }
    else{
      printf $fid_ver "+ (x%d", $oper_mat_ref->[$i][6];
    }
    if ($oper_mat_ref->[$i][7]){
      printf $fid_ver "<<<%d", $oper_mat_ref->[$i][7];
    }
    printf $fid_ver ")); \n";

    if ($oper_mat_ref->[$i][1]){
      printf $fid_ver "assign x%d = (x%ds%d>>>%d); \n", $oper_mat_ref->[$i][0], $oper_mat_ref->[$i][0], $oper_mat_ref->[$i][1], $oper_mat_ref->[$i][1];
    }
    printf $fid_ver "\n";
  }

  printf $fid_ver "// Realization of Coefficients \n";
  for (my $i=0; $i<$mcm_coef_cnt; $i++){
    if ($mcm_coef_arr_ref->[$i] < 0){
      printf $fid_ver "assign m%dx = -(", abs($mcm_coef_arr_ref->[$i]);
    }
    else{
      printf $fid_ver "assign p%dx = (", $mcm_coef_arr_ref->[$i];
    }
    my ($the_sign, $the_shift, $posodd_num) = make_number_posodd($mcm_coef_arr_ref->[$i]);
    if ($the_shift){
      printf $fid_ver "x%d<<<%d); \n", $posodd_num, $the_shift;
    }
    else{
      printf $fid_ver "x%d); \n", $mcm_coef_arr_ref->[$i];
    }
  }

  printf $fid_ver "\n";
  printf $fid_ver "endmodule\n";

  close ($fid_ver);
}

sub solve_mcm_problem{
  my ($file_dir, $file_name, $file_mcm, $mcm_coef_cnt, $mcm_coef_arr_ref) = @_;

  my $mcm_step_ref = 0;
  my $mcm_oper = 0;
  my $mcm_step = 0;
  my $mcm_cpu = 0;

  my $paths_ok = 0;
  my $path_mcm_algo = "";
  my $path_mcm_high2low = "";

  if ($mcm_algo eq "exact"){
    ($paths_ok, $path_mcm_algo, $path_mcm_high2low) = extract_paths("paths.pl", "mcm");
  }
  else{
    ($paths_ok, $path_mcm_algo, $path_mcm_high2low) = extract_paths("paths.pl", "hcub");
  }

  my $the_cmd = "";
  if ($paths_ok){
    if ($the_verb > 0){print "[INFO] Solving the MCM problem... \n";}
    
    my $init_time = time();
    my $file_mcm_result = $file_dir . $file_name . "_mcm.result";

    #Run the MCM algorithm
    if ($mcm_algo eq "exact"){
      if ($mcm_aim eq "oper"){
        $the_cmd = $path_mcm_algo . " " . $file_mcm . " 0 " . $dfs_time;
      }
      else{
        $the_cmd = $path_mcm_algo . " " . $file_mcm . " 1 " . $dfs_time;
      }
      system($the_cmd);
      $mcm_cpu = time() - $init_time;

      ($mcm_oper, $mcm_step_ref) = extract_mcm_oper_ours($file_mcm_result);
    }
    else{
      $the_cmd = $path_mcm_algo . " ";
      for (my $i=0; $i<$mcm_coef_cnt; $i++){
        $the_cmd .= $mcm_coef_arr_ref->[$i] . " ";
      }
      $the_cmd .= "-ga";

      if ($mcm_aim eq "oper"){
        $the_cmd .= " > " . $file_mcm_result;
      }
      else{
        $the_cmd .= " -maxdepth 0 > " . $file_mcm_result;
      }
      system($the_cmd);
      $mcm_cpu = time() - $init_time;
      
      ($mcm_oper, $mcm_step, $mcm_step_ref) = extract_mcm_oper_hcub($file_mcm_result);
      if ($the_verb > 0){printf "[INFO] A solution with %d operations in %d adder-steps is obtained in %.2f seconds! \n", $mcm_oper, $mcm_step, $mcm_cpu;}
    }

    #Generate the Verilog file
    if ($the_verb > 0){print "[INFO] Generating the MCM design in Verilog... \n";}
    if ($mcm_algo eq "exact"){
      $the_cmd = $path_mcm_high2low . " " . $file_mcm_result . " " . $in_width . " " . $is_signed;
      system($the_cmd);
    }
    else{
      generate_mcm_hcub_verilog($file_dir, $file_name, $mcm_coef_cnt, $mcm_coef_arr_ref);
    }
  }

  return ($mcm_oper, $mcm_cpu, $mcm_step_ref);
}

sub partition_digit{
  my ($file_dir, $file_name, $coef_cnt, $coef_width_arr_ref, $coef_ref_arr_ref) = @_;

  my $seqexp_cnt = 0;
  my @seqexp_arr = ();

  my $mcm_coef_cnt = 0;
  my @mcm_coef_arr = ();

  my @num_cnt_arr = ();
  my @num_val_mat = ();
  my @num_step_mat = ();
  my @num_shift_mat = ();
  my @num_width_mat = ();

  my $init_dig = 0;
  my $par_val = 0;
  my $dig_pos = 0;
  my $seq_f = 1;
  my $seq_0 = 1;

  my $file_mcm = $file_dir . $file_name . "_mcm.coef";
  open (my $fid_mcm, '>', $file_mcm);

  for (my $i=0; $i<$coef_cnt; $i++){
    $num_cnt_arr[$i] = 0;
    $init_dig = 0;
    $dig_pos = 0;
    $par_val = 0;
    $seq_f = 1;
    $seq_0 = 1;
    for (my $j=0; $j<$coef_width_arr_ref->[$i]; $j++){
      my $the_char = $coef_ref_arr_ref->[$i]->[$j];
      
      #Compute the value of partition
      if ($dig_pos < $dig_par){
        my ($the_dec) = hex2dec($the_char);
        $par_val += $the_dec*(16**$dig_pos);  #Hexadecimal computation
      }
 
      #Make a decision
      if ($dig_pos == $dig_par-1){
        #Check the sequence of 0s and Fs
        if ($the_char ne "0"){
          $seq_0 = 0;
        }
        if ($the_char ne "f" and $the_char ne "F"){
          $seq_f = 0;
        }
        
        if ($seq_0 or $seq_f){
          $dig_pos++;
        }
        else{
          if ($par_val){
            $num_val_mat[$i][$num_cnt_arr[$i]] = $par_val;
            $num_shift_mat[$i][$num_cnt_arr[$i]] = $init_dig*4;
            $num_width_mat[$i][$num_cnt_arr[$i]] = POSIX::ceil(log($par_val)/log(2)) + $in_width;
            $num_cnt_arr[$i]++;
          
            if (is_inside_numeric_array($par_val, $mcm_coef_cnt, \@mcm_coef_arr) == -1){
              printf $fid_mcm "%d \n", $par_val;
              $mcm_coef_arr[$mcm_coef_cnt] = $par_val;
              $mcm_coef_cnt++;
            }
          }

          $init_dig = $j+1;
          $dig_pos = 0;
          $par_val = 0;
          $seq_f = 1;
          $seq_0 = 1;
        }
      }
      elsif ($dig_pos >= $dig_par){
        if ($seq_0 == 1 and $the_char ne "0"){
          $init_dig = $j;
          $dig_pos = 1;
          $par_val = hex2dec($the_char);
          $seq_0 = 0;
          if ($the_char eq "f" or $the_char eq "F"){
            $seq_f = 1;
          }
          else{
            $seq_f = 0;

            ### Exceptional case when digits in partition is 1
            if ($dig_par == 1){
              if ($par_val){
                $num_val_mat[$i][$num_cnt_arr[$i]] = $par_val;
                $num_shift_mat[$i][$num_cnt_arr[$i]] = $init_dig*4;
                $num_width_mat[$i][$num_cnt_arr[$i]] = POSIX::ceil(log($par_val)/log(2)) + $in_width;
                $num_cnt_arr[$i]++;

                if (is_inside_numeric_array($par_val, $mcm_coef_cnt, \@mcm_coef_arr) == -1){
                  printf $fid_mcm "%d \n", $par_val;
                  $mcm_coef_arr[$mcm_coef_cnt] = $par_val;
                  $mcm_coef_cnt++;
                }
              }

              $init_dig = $j+1;
              $dig_pos = 0;
              $par_val = 0;
            }
          }
        }
        elsif ($seq_f == 1 and $the_char ne "f" and $the_char ne "F"){
          $num_val_mat[$i][$num_cnt_arr[$i]] = (-1)*$dig_pos;
          $num_shift_mat[$i][$num_cnt_arr[$i]] = $init_dig*4;
          $num_width_mat[$i][$num_cnt_arr[$i]] = $dig_pos*4 + $in_width;
          $num_cnt_arr[$i]++;

          if (is_inside_numeric_array($dig_pos, $seqexp_cnt, \@seqexp_arr) == -1){
            $seqexp_arr[$seqexp_cnt] = $dig_pos;
            $seqexp_cnt++;
          }

          $init_dig = $j;
          $dig_pos = 1;
          $par_val = hex2dec($the_char);
          $seq_f = 0;
          if ($the_char eq "0"){
            $seq_0 = 1;
          }
          else{
            $seq_0 = 0;

            ### Exceptional case when digits in partition is 1
            if ($dig_par == 1){
              if ($par_val){
                $num_val_mat[$i][$num_cnt_arr[$i]] = $par_val;
                $num_shift_mat[$i][$num_cnt_arr[$i]] = $init_dig*4;
                $num_width_mat[$i][$num_cnt_arr[$i]] = POSIX::ceil(log($par_val)/log(2)) + $in_width;
                $num_cnt_arr[$i]++;

                if (is_inside_numeric_array($par_val, $mcm_coef_cnt, \@mcm_coef_arr) == -1){
                  printf $fid_mcm "%d \n", $par_val;
                  $mcm_coef_arr[$mcm_coef_cnt] = $par_val;
                  $mcm_coef_cnt++;
                }
              }

              $init_dig = $j+1;
              $dig_pos = 0;
              $par_val = 0;
              $seq_f = 0;
            }
          }
        }
        else{
          $dig_pos++;
        }
      }
      else{
        #Check the sequence of 0s and Fs
        if ($the_char ne "0"){
          $seq_0 = 0;
        }
        if ($the_char ne "f" and $the_char ne "F"){
          $seq_f = 0;
        }

        $dig_pos++;
      }
    }

    if ($dig_pos > 0 and $dig_pos < $dig_par){
      if ($par_val){
        $num_val_mat[$i][$num_cnt_arr[$i]] = $par_val;
        $num_shift_mat[$i][$num_cnt_arr[$i]] = $init_dig*4;
        $num_width_mat[$i][$num_cnt_arr[$i]] = POSIX::ceil(log($par_val)/log(2)) + $in_width;
        $num_cnt_arr[$i]++;

        if (is_inside_numeric_array($par_val, $mcm_coef_cnt, \@mcm_coef_arr) == -1){
          printf $fid_mcm "%d \n", $par_val;
          $mcm_coef_arr[$mcm_coef_cnt] = $par_val;
          $mcm_coef_cnt++;
        }
      }
    }
    elsif ($dig_pos >= $dig_par){
      if ($seq_f == 1){
        $num_val_mat[$i][$num_cnt_arr[$i]] = (-1)*$dig_pos;
        $num_shift_mat[$i][$num_cnt_arr[$i]] = $init_dig*4;
        $num_width_mat[$i][$num_cnt_arr[$i]] = $dig_pos*4 + $in_width;
        $num_cnt_arr[$i]++;

        if (is_inside_numeric_array($dig_pos, $seqexp_cnt, \@seqexp_arr) == -1){
          $seqexp_arr[$seqexp_cnt] = $dig_pos;
          $seqexp_cnt++;
        }
      }
    }
  }
  
  close ($fid_mcm);

  return ($file_mcm, $seqexp_cnt, \@seqexp_arr, $mcm_coef_cnt, \@mcm_coef_arr, \@num_cnt_arr, \@num_val_mat, \@num_shift_mat, \@num_width_mat, \@num_step_mat);
}

sub determine_next_max_occ_term{
  my ($terms_cnt, $terms_arr_ref, $terms_occ_cnt_arr_ref, $terms_occ_mat_ref, $replace_mat_ref) = @_;

  my $max_noc = 0;
  my $max_occ_term = -1;

  for (my $i=0; $i<$terms_cnt; $i++){
    if ($terms_occ_cnt_arr_ref->[$i] > 1){
      my $occ_cnt = 0;

      for (my $j=0; $j<$terms_occ_cnt_arr_ref->[$i]; $j++){
        my $coef_index = $terms_occ_mat_ref->[$i][2*$j];
        my $pos_index = $terms_occ_mat_ref->[$i][2*$j+1];

        if ($replace_mat_ref->[$coef_index][$pos_index] == -1 and $replace_mat_ref->[$coef_index][$pos_index+$dig_par-1] == -1){
          $occ_cnt++;
        }
      }

      if ($occ_cnt > $max_noc){
        $max_noc = $occ_cnt;
        $max_occ_term = $i;
      }
    }
  }

  return ($max_noc, $max_occ_term);
}

sub determine_partitions{
  my ($file_dir, $file_name, $coef_cnt, $coef_width_arr_ref, $coef_ref_arr_ref, $replace_mat_ref) = @_;

  my $seqexp_cnt = 0;
  my @seqexp_arr = ();

  my $mcm_coef_cnt = 0;
  my @mcm_coef_arr = ();

  my @num_cnt_arr = ();
  my @num_val_mat = ();
  my @num_step_mat = ();
  my @num_shift_mat = ();
  my @num_width_mat = ();

  my $init_dig = 0;
  my $par_val = 0;
  my $dig_pos = 0;
  my $seq_f = 1;
  my $seq_0 = 1;

  my $file_mcm = $file_dir . $file_name . "_mcm.coef";
  open (my $fid_mcm, '>', $file_mcm);

  for (my $i=0; $i<$coef_cnt; $i++){
    $num_cnt_arr[$i] = 0;
    $init_dig = 0;
    $dig_pos = 0;
    $par_val = 0;
    $seq_f = 1;
    $seq_0 = 1;

    my $dig_ind = 0;
    while ($dig_ind < $coef_width_arr_ref->[$i]){
      if ($replace_mat_ref->[$i][$dig_ind] == -1){
        my $the_char = $coef_ref_arr_ref->[$i]->[$dig_ind];
        
        #Compute the value of partition
        if ($dig_pos < $dig_par){
          my ($the_dec) = hex2dec($the_char);
          $par_val += $the_dec*(16**$dig_pos);  #Hexadecimal computation
        }
 
        #Make a decision
        if ($dig_pos == $dig_par-1){
          #Check the sequence of 0s and Fs
          if ($the_char ne "0"){
            $seq_0 = 0;
          }
          if ($the_char ne "f" and $the_char ne "F"){
            $seq_f = 0;
          }
          
          if ($seq_0 or $seq_f){
            $dig_pos++;
          }
          else{
            if ($par_val){
              $num_val_mat[$i][$num_cnt_arr[$i]] = $par_val;
              $num_shift_mat[$i][$num_cnt_arr[$i]] = $init_dig*4;
              $num_width_mat[$i][$num_cnt_arr[$i]] = POSIX::ceil(log($par_val)/log(2)) + $in_width;
              $num_cnt_arr[$i]++;
            
              if (is_inside_numeric_array($par_val, $mcm_coef_cnt, \@mcm_coef_arr) == -1){
                printf $fid_mcm "%d \n", $par_val;
                $mcm_coef_arr[$mcm_coef_cnt] = $par_val;
                $mcm_coef_cnt++;
              }
            }

            $init_dig = $dig_ind+1;
            $dig_pos = 0;
            $par_val = 0;
            $seq_f = 1;
            $seq_0 = 1;
          }
        }
        elsif ($dig_pos >= $dig_par){
          if ($seq_0 == 1 and $the_char ne "0"){
            $init_dig = $dig_ind;
            $dig_pos = 1;
            $par_val = hex2dec($the_char);
            $seq_0 = 0;
            if ($the_char eq "f" or $the_char eq "F"){
              $seq_f = 1;
            }
            else{
              $seq_f = 0;
            }
          }
          elsif ($seq_f == 1 and $the_char ne "f" and $the_char ne "F"){
            $num_val_mat[$i][$num_cnt_arr[$i]] = (-1)*$dig_pos;
            $num_shift_mat[$i][$num_cnt_arr[$i]] = $init_dig*4;
            $num_width_mat[$i][$num_cnt_arr[$i]] = $dig_pos*4 + $in_width;
            $num_cnt_arr[$i]++;

            if (is_inside_numeric_array($dig_pos, $seqexp_cnt, \@seqexp_arr) == -1){
              $seqexp_arr[$seqexp_cnt] = $dig_pos;
              $seqexp_cnt++;
            }

            $init_dig = $dig_ind;
            $dig_pos = 1;
            $par_val = hex2dec($the_char);
            $seq_f = 0;
            if ($the_char eq "0"){
              $seq_0 = 1;
            }
            else{
              $seq_0 = 0;

            }
          }
          else{
            $dig_pos++;
          }
        }
        else{
          #Check the sequence of 0s and Fs
          if ($the_char ne "0"){
            $seq_0 = 0;
          }
          if ($the_char ne "f" and $the_char ne "F"){
            $seq_f = 0;
          }

          $dig_pos++;
        }
      }
      else{
        #Previously computed of sequence of Fs
        if ($seq_f == 1 and $dig_pos){
          $num_val_mat[$i][$num_cnt_arr[$i]] = (-1)*$dig_pos;
          $num_shift_mat[$i][$num_cnt_arr[$i]] = $init_dig*4;
          $num_width_mat[$i][$num_cnt_arr[$i]] = $dig_pos*4 + $in_width;
          $num_cnt_arr[$i]++;

          if (is_inside_numeric_array($dig_pos, $seqexp_cnt, \@seqexp_arr) == -1){
            $seqexp_arr[$seqexp_cnt] = $dig_pos;
            $seqexp_cnt++;
          }
        }
        #Previously computed constant
        elsif ($par_val){
          $num_val_mat[$i][$num_cnt_arr[$i]] = $par_val;
          $num_shift_mat[$i][$num_cnt_arr[$i]] = $init_dig*4;
          $num_width_mat[$i][$num_cnt_arr[$i]] = POSIX::ceil(log($par_val)/log(2)) + $in_width;
          $num_cnt_arr[$i]++;
        
          if (is_inside_numeric_array($par_val, $mcm_coef_cnt, \@mcm_coef_arr) == -1){
            printf $fid_mcm "%d \n", $par_val;
            $mcm_coef_arr[$mcm_coef_cnt] = $par_val;
            $mcm_coef_cnt++;
          }
        }

        #Selected common subexpression
        $num_val_mat[$i][$num_cnt_arr[$i]] = $replace_mat_ref->[$i][$dig_ind];
        $num_shift_mat[$i][$num_cnt_arr[$i]] = $dig_ind*4;
        $num_width_mat[$i][$num_cnt_arr[$i]] = POSIX::ceil(log($replace_mat_ref->[$i][$dig_ind])/log(2)) + $in_width;
        $num_cnt_arr[$i]++;
        
        if (is_inside_numeric_array($replace_mat_ref->[$i][$dig_ind], $mcm_coef_cnt, \@mcm_coef_arr) == -1){
          printf $fid_mcm "%d \n", $replace_mat_ref->[$i][$dig_ind];
          $mcm_coef_arr[$mcm_coef_cnt] = $replace_mat_ref->[$i][$dig_ind];
          $mcm_coef_cnt++;
        }

        $dig_ind += $dig_par-1;
        $init_dig = $dig_ind+1;
        $dig_pos = 0;
        $par_val = 0;
        $seq_f = 1;
        $seq_0 = 1;
      }

      $dig_ind++;
    }

    if ($dig_pos > 0 and $dig_pos < $dig_par){
      if ($par_val){
        $num_val_mat[$i][$num_cnt_arr[$i]] = $par_val;
        $num_shift_mat[$i][$num_cnt_arr[$i]] = $init_dig*4;
        $num_width_mat[$i][$num_cnt_arr[$i]] = POSIX::ceil(log($par_val)/log(2)) + $in_width;
        $num_cnt_arr[$i]++;

        if (is_inside_numeric_array($par_val, $mcm_coef_cnt, \@mcm_coef_arr) == -1){
          printf $fid_mcm "%d \n", $par_val;
          $mcm_coef_arr[$mcm_coef_cnt] = $par_val;
          $mcm_coef_cnt++;
        }
      }
    }
    elsif ($dig_pos >= $dig_par){
      if ($seq_f == 1){
        $num_val_mat[$i][$num_cnt_arr[$i]] = (-1)*$dig_pos;
        $num_shift_mat[$i][$num_cnt_arr[$i]] = $init_dig*4;
        $num_width_mat[$i][$num_cnt_arr[$i]] = $dig_pos*4 + $in_width;
        $num_cnt_arr[$i]++;

        if (is_inside_numeric_array($dig_pos, $seqexp_cnt, \@seqexp_arr) == -1){
          $seqexp_arr[$seqexp_cnt] = $dig_pos;
          $seqexp_cnt++;
        }
      }
    }
  }

  close ($fid_mcm);

  return ($file_mcm, $seqexp_cnt, \@seqexp_arr, $mcm_coef_cnt, \@mcm_coef_arr, \@num_cnt_arr, \@num_val_mat, \@num_shift_mat, \@num_width_mat, \@num_step_mat);
}

sub extract_common_terms{
  my ($file_dir, $file_name, $coef_cnt, $coef_width_arr_ref, $coef_ref_arr_ref, $max_occ, $max_occ_term, $terms_cnt, $terms_arr_ref, $terms_occ_cnt_arr_ref, $terms_occ_mat_ref) = @_;

  my @replace_mat = ();
  for (my $i=0; $i<$coef_cnt; $i++){
    for (my $j=0; $j<$coef_width_arr_ref->[$i]; $j++){
      $replace_mat[$i][$j] = -1;
    }
  }

  my $seq0 = "";
  my $seqf = "";
  my $seqF = "";
  for (my $i=0; $i<$dig_par; $i++){
    $seq0 .= "0";
    $seqf .= "f";
    $seqF .= "F";
  }

  while ($max_occ > 1){
    if (($terms_arr_ref->[$max_occ_term] ne $seq0) and ($terms_arr_ref->[$max_occ_term] ne $seqf) and ($terms_arr_ref->[$max_occ_term] ne $seqF)){
      for (my $i=0; $i<$terms_occ_cnt_arr_ref->[$max_occ_term]; $i++){
        my $coef_index = $terms_occ_mat_ref->[$max_occ_term][2*$i];
        my $pos_index = $terms_occ_mat_ref->[$max_occ_term][2*$i+1];

        if ($replace_mat[$coef_index][$pos_index] == -1 and $replace_mat[$coef_index][$pos_index+$dig_par-1] == -1){
          my $dig_num=0;
          while ($dig_num < $dig_par){
            $replace_mat[$coef_index][$pos_index+$dig_num] = hexterm2decimal($terms_arr_ref->[$max_occ_term]);
            $dig_num++;
          }
        }
      }
    }

    $terms_occ_cnt_arr_ref->[$max_occ_term] = 0;

    #Determine next most common nonoverlapping term
    ($max_occ, $max_occ_term) = determine_next_max_occ_term($terms_cnt, $terms_arr_ref, $terms_occ_cnt_arr_ref, $terms_occ_mat_ref, \@replace_mat);
  }

  my ($file_mcm, $seqexp_cnt, $seqexp_arr_ref, $mcm_coef_cnt, $mcm_coef_arr_ref, $num_cnt_arr_ref, $num_val_mat_ref, $num_shift_mat_ref, $num_width_mat_ref, $num_step_mat_ref) = determine_partitions($file_dir, $file_name, $coef_cnt, $coef_width_arr_ref, $coef_ref_arr_ref, \@replace_mat);

  return ($file_mcm, $seqexp_cnt, $seqexp_arr_ref, $mcm_coef_cnt, $mcm_coef_arr_ref, $num_cnt_arr_ref, $num_val_mat_ref, $num_shift_mat_ref, $num_width_mat_ref, $num_step_mat_ref);
}

sub find_nonoverlap_term_occurrences{
  my ($coef_cnt, $coef_width_arr_ref, $coef_ref_arr_ref, $coef_index, $pos_index, $the_term, $term_index, $terms_occ_cnt_arr_ref, $terms_occ_mat_ref) = @_;

  my $term_coef = $coef_index;
  my $term_pos = $pos_index-$dig_par;

  while ($coef_index < $coef_cnt){
    my $the_pointer = $pos_index;

    while ($the_pointer < $coef_width_arr_ref->[$coef_index]-$dig_par+1){
      my $dig_num = 0;
      my $is_same = 1;
      my $init_pointer = $the_pointer;
      while ($dig_num < $dig_par){
        if ($coef_ref_arr_ref->[$term_coef]->[$term_pos+$dig_num] ne $coef_ref_arr_ref->[$coef_index]->[$the_pointer+$dig_num]){
          $is_same = 0;
          $the_pointer += $dig_num;
          last;
        }
        else{
          $dig_num++;
        }
      }
      if ($is_same == 1){
        $terms_occ_mat_ref->[$term_index][2*$terms_occ_cnt_arr_ref->[$term_index]] = $coef_index;
        $terms_occ_mat_ref->[$term_index][2*$terms_occ_cnt_arr_ref->[$term_index]+1] = $init_pointer;
        $terms_occ_cnt_arr_ref->[$term_index]++;
        $the_pointer += $dig_par-1;
      }

      $the_pointer++;
    }

    $coef_index++;
    $pos_index = 0;
  }

  return ($terms_occ_cnt_arr_ref, $terms_occ_mat_ref);
}

sub partition_common_terms{
  my ($file_dir, $file_name, $coef_cnt, $coef_width_arr_ref, $coef_ref_arr_ref) = @_;
  
  my $terms_cnt = 0;
  my @terms_arr = ();
  my @terms_occ_mat = ();
  my @terms_occ_cnt_arr = ();
  my $terms_occ_mat_ref = \@terms_occ_mat;
  my $terms_occ_cnt_arr_ref = \@terms_occ_cnt_arr;

  my $max_occ = 0;
  my $max_occ_term = -1;

  #Find Common Terms
  for (my $i=0; $i<$coef_cnt; $i++){
    for (my $j=0; $j<$coef_width_arr_ref->[$i]-$dig_par+1; $j++){
      my $the_term = "";
      my $dig_num = 0;
      while ($dig_num < $dig_par){
        $the_term .= $coef_ref_arr_ref->[$i]->[$j+$dig_num];
        $dig_num++;
      }

      my ($term_index) = is_inside_string_array($the_term, $terms_cnt, \@terms_arr);
      if ($term_index == -1){
        $terms_arr[$terms_cnt] = $the_term;
        $terms_occ_cnt_arr_ref->[$terms_cnt] = 1;
        $terms_occ_mat_ref->[$terms_cnt][0] = $i;
        $terms_occ_mat_ref->[$terms_cnt][1] = $j;

        ($terms_occ_cnt_arr_ref, $terms_occ_mat_ref) = find_nonoverlap_term_occurrences($coef_cnt, $coef_width_arr_ref, $coef_ref_arr_ref, $i, $j+$dig_par, $the_term, $terms_cnt, $terms_occ_cnt_arr_ref, $terms_occ_mat_ref);
        
        if ($terms_occ_cnt_arr_ref->[$terms_cnt] > $max_occ){
          $max_occ = $terms_occ_cnt_arr_ref->[$terms_cnt];
          $max_occ_term = $terms_cnt;
        }

        $terms_cnt++;
      }
    }
  }

  if ($max_occ < 2){
    if ($the_verb > 1){print "[INFO] There exists no common digit patterns \n";}
  }

  my ($file_mcm, $seqexp_cnt, $seqexp_arr_ref, $mcm_coef_cnt, $mcm_coef_arr_ref, $num_cnt_arr_ref, $num_val_mat_ref, $num_shift_mat_ref, $num_width_mat_ref, $num_step_mat_ref) = extract_common_terms($file_dir, $file_name, $coef_cnt, $coef_width_arr_ref, $coef_ref_arr_ref, $max_occ, $max_occ_term, $terms_cnt, \@terms_arr, $terms_occ_cnt_arr_ref, $terms_occ_mat_ref);

  return ($file_mcm, $seqexp_cnt, $seqexp_arr_ref, $mcm_coef_cnt, $mcm_coef_arr_ref, $num_cnt_arr_ref, $num_val_mat_ref, $num_shift_mat_ref, $num_width_mat_ref, $num_step_mat_ref);
}

sub preprocess_generate_mcm_block{
  my ($file_dir, $file_name, $coef_cnt, $coef_width_arr_ref, $coef_ref_arr_ref) = @_;

  my $mcm_oper = 0;
  my $mcm_cpu = 0;
  my $mcm_step_ref;

  my $file_mcm;
  my $seqexp_cnt; 
  my $mcm_coef_cnt; 
  my $seqexp_arr_ref;
  my $num_cnt_arr_ref; 
  my $num_val_mat_ref; 
  my $num_step_mat_ref;
  my $mcm_coef_arr_ref; 
  my $num_shift_mat_ref; 
  my $num_width_mat_ref;

  if ($the_verb > 0){printf "[INFO] Partitioning the hexadecimal digits... \n";}

  if ($par_tech == 0 or ($par_tech == 1 and $dig_par == 1)){
    ($file_mcm, $seqexp_cnt, $seqexp_arr_ref, $mcm_coef_cnt, $mcm_coef_arr_ref, $num_cnt_arr_ref, $num_val_mat_ref, $num_shift_mat_ref, $num_width_mat_ref, $num_step_mat_ref) = partition_digit($file_dir, $file_name, $coef_cnt, $coef_width_arr_ref, $coef_ref_arr_ref);
  }
  elsif ($par_tech == 1){
    ($file_mcm, $seqexp_cnt, $seqexp_arr_ref, $mcm_coef_cnt, $mcm_coef_arr_ref, $num_cnt_arr_ref, $num_val_mat_ref, $num_shift_mat_ref, $num_width_mat_ref, $num_step_mat_ref) = partition_common_terms($file_dir, $file_name, $coef_cnt, $coef_width_arr_ref, $coef_ref_arr_ref);
  }

  if ($mcm_coef_cnt){
    ($mcm_oper, $mcm_cpu, $mcm_step_ref) = solve_mcm_problem($file_dir, $file_name, $file_mcm, $mcm_coef_cnt, $mcm_coef_arr_ref); 

    for (my $i=0; $i<$coef_cnt; $i++){
      for (my $j=0; $j<$num_cnt_arr_ref->[$i]; $j++){
        if ($num_val_mat_ref->[$i][$j] > 0){
          my ($the_sign, $the_shift, $posodd_num) = make_number_posodd($num_val_mat_ref->[$i][$j]);
          #print "posodd_num: $posodd_num \n";
          if ($posodd_num == 1){
            $num_step_mat_ref->[$i][$j] = 0;
          }
          else{
            $num_step_mat_ref->[$i][$j] = extract_operand_step($posodd_num, $mcm_oper, $mcm_step_ref);
          }
        }
        else{
          $num_step_mat_ref->[$i][$j] = 1;
        }
      }
    }
  }

  return ($mcm_oper, $mcm_cpu, $seqexp_cnt, $seqexp_arr_ref, $mcm_coef_cnt, $mcm_coef_arr_ref, $num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref);
}

sub describe_gm_design_verilog{
  my ($file_dir, $file_name, $coef_cnt, $coef_width_arr_ref, $coef_ref_arr_ref) = @_;

  my $signed_str = $is_signed ? "signed " : "";

  my @out_width_arr = ();
  for (my $i=0; $i<$coef_cnt; $i++){
    $out_width_arr[$i] = $coef_width_arr_ref->[$i]*4+$in_width;
  }

  if ($the_verb > 0){printf "[INFO] Generating the design in Verilog... \n";}
  my $file_verilog = $file_dir . $file_name . ".v";
  open (my $fid_ver, '>', $file_verilog);

  my $date_time = localtime();
  printf $fid_ver "// Behavioral Description of a Large Constant Multiplication in Verilog using a Generic Multiplier\n";
  printf $fid_ver "// Date: %s \n", $date_time;
  printf $fid_ver "// Coefficient File: %s \n", $coef_file; 

  printf $fid_ver "\n";

  #TOP Module
  printf $fid_ver "module %s (", $file_name;
  for (my $i=0; $i<$coef_cnt; $i++){
    printf $fid_ver "y_out%d, ", $i;
  }
  printf $fid_ver "x_in); \n";
  printf $fid_ver "\n";

  #IOs
  printf $fid_ver "// Declaration of IOs \n"; 
  printf $fid_ver "input %s[%d:0] x_in; \n", $signed_str, $in_width-1;
  for (my $i=0; $i<$coef_cnt; $i++){
    printf $fid_ver "output %s[%d:0] y_out%d; \n", $signed_str, $out_width_arr[$i]-1, $i;
  }
  printf $fid_ver "\n";

  #Wires
  printf $fid_ver "// Declaration of Wires \n"; 
  for (my $i=0; $i<$coef_cnt; $i++){
    if ($is_signed == 0){
      printf $fid_ver "wire [%d:0] c%d = %d'h", $coef_width_arr_ref->[$i]*4-1, $i, $coef_width_arr_ref->[$i]*4;
    }
    else{
      printf $fid_ver "wire signed [%d:0] c%d = {1'b0, %d'h", $coef_width_arr_ref->[$i]*4, $i, $coef_width_arr_ref->[$i]*4;
    }
    for (my $j=$coef_width_arr_ref->[$i]-1; $j>=0; $j--){
      printf $fid_ver "%s", $coef_ref_arr_ref->[$i]->[$j];
    }
    if ($is_signed == 0){
      printf $fid_ver "; \n";
    }
    else{
      printf $fid_ver "}; \n";
    }
  }
  printf $fid_ver "\n";

  #Output Realizations
  printf $fid_ver "// Realization of Outputs \n"; 
  for (my $i=0; $i<$coef_cnt; $i++){
    printf $fid_ver "assign y_out%d = c%d * x_in; \n", $i, $i;
  }
  printf $fid_ver "\n";
  
  printf $fid_ver "endmodule \n"; 

  close $fid_ver;

  return (\@out_width_arr);
}

sub describe_sa_design_verilog{
  my ($file_dir, $file_name, $mcm_oper, $exp_oper, $sum_oper, $tot_oper, $adder_step, $seqexp_cnt, $seqexp_arr_ref, $mcm_coef_cnt, $mcm_coef_arr_ref, $num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $coef_cnt, $coef_width_arr_ref, $subexp_cnt, $subexp_cse_cnt, $subexp_arr_ref) = @_;

  my $subexp_str = "";
  my $signed_str = $is_signed ? "signed " : "";

  my @out_width_arr = ();
  for (my $i=0; $i<$coef_cnt; $i++){
    $out_width_arr[$i] = $coef_width_arr_ref->[$i]*4+$in_width;
  }

  if ($the_verb > 0){printf "[INFO] Generating the design in Verilog... \n";}
  my $file_verilog = $file_dir . $file_name . ".v";
  open (my $fid_ver, '>', $file_verilog);

  my $date_time = localtime();
  printf $fid_ver "// Behavioral Description of a Large Constant Multiplication under the Shift-Adds Architecture in Verilog \n";
  printf $fid_ver "// Date: %s \n", $date_time;
  printf $fid_ver "// Coefficient File: %s \n", $coef_file; 
  printf $fid_ver "// Number of adders/subtractors in the MCM block: %d \n", $mcm_oper;
  printf $fid_ver "// Number of adders/subtractors in the CSE block: %d \n", $exp_oper;
  printf $fid_ver "// Number of adders/subtractors in the linear equations: %d \n", $sum_oper;
  printf $fid_ver "// Total number of adders/subtractors: %d \n", $tot_oper;
  printf $fid_ver "// Number of adder-steps: %d \n", $adder_step;

  printf $fid_ver "\n";

  #MCM Module
  my $module_mcm = $file_name . "_mcm";
  if ($mcm_coef_cnt){
    printf $fid_ver "`include \"%s.v\" \n", $module_mcm;
    printf $fid_ver "\n";
  }

  #TOP Module
  printf $fid_ver "module %s (", $file_name;
  for (my $i=0; $i<$coef_cnt; $i++){
    printf $fid_ver "y_out%d, ", $i;
  }
  printf $fid_ver "x_in); \n";
  printf $fid_ver "\n";

  #IOs
  printf $fid_ver "// Declaration of IOs \n"; 
  printf $fid_ver "input %s[%d:0] x_in; \n", $signed_str, $in_width-1;
  for (my $i=0; $i<$coef_cnt; $i++){
    printf $fid_ver "output %s[%d:0] y_out%d; \n", $signed_str, $out_width_arr[$i]-1, $i;
  }
  printf $fid_ver "\n";

  #Wires
  printf $fid_ver "// Declaration of Wires \n"; 
  if ($mcm_coef_cnt){printf $fid_ver "// Variables of the MCM Block \n";}
  for (my $i=0; $i<$mcm_coef_cnt; $i++){
    printf $fid_ver "wire %s[%d:0] p%dx; \n", $signed_str, $in_width+POSIX::ceil(log($mcm_coef_arr_ref->[$i])/log(2))-1, $mcm_coef_arr_ref->[$i];
  }
  if ($seqexp_cnt){printf $fid_ver "// Variables of the Sequence Expressions \n";}
  for (my $i=0; $i<$seqexp_cnt; $i++){
    printf $fid_ver "wire %s[%d:0] seqf%dx; \n", $signed_str, $in_width+($seqexp_arr_ref->[$i]*4)-1, ($seqexp_arr_ref->[$i]);
  }
  if ($subexp_cse_cnt){printf $fid_ver "// Variables of the Subexpressions for CSE \n";}
  for (my $i=0; $i<$subexp_cnt; $i++){
    if ($i == $subexp_cse_cnt){printf $fid_ver "// Variables of the Subexpressions for Linear Equations \n";}
    printf $fid_ver "wire %s[%d:0] exp%d; \n", $signed_str, $subexp_arr_ref->[$i][4]-1, $i;
  }
  printf $fid_ver "\n";

  #Subexpression Realizations
  printf $fid_ver "// Realization of Subexpressions \n"; 
  if ($seqexp_cnt){printf $fid_ver "// Sequence Expressions \n";}
  for (my $i=0; $i<$seqexp_cnt; $i++){
    printf $fid_ver "assign seqf%dx = ( (x_in<<<%d) - (x_in) ); \n", ($seqexp_arr_ref->[$i]), ($seqexp_arr_ref->[$i]*4);
  }
  if ($subexp_cse_cnt){printf $fid_ver "// Subexpressions for CSE \n";}
  for (my $i=0; $i<$subexp_cnt; $i++){
    if ($i == $subexp_cse_cnt){printf $fid_ver "// Subexpressions for Linear Equations \n";}
    $subexp_str = "assign exp" . $i . " = ( (";
    
    #First operand variable
    if ($subexp_arr_ref->[$i][0] > 0){
      $subexp_str .= "p" . $subexp_arr_ref->[$i][0] . "x";
    }
    elsif ($subexp_arr_ref->[$i][0] < 0 and $subexp_arr_ref->[$i][0] > -1000){
      $subexp_str .= "seqf" . abs($subexp_arr_ref->[$i][0]) . "x";
    }
    elsif ($subexp_arr_ref->[$i][0] <= -1000){
      $subexp_str .= "exp" . abs($subexp_arr_ref->[$i][0]+1000);
    }
    #First operand shift
    if ($subexp_arr_ref->[$i][1] > 0){
      $subexp_str .= "<<<" . $subexp_arr_ref->[$i][1] . ") + (";
    }
    else{
      $subexp_str .= ") + ("
    }
    #Second operand variable
    if ($subexp_arr_ref->[$i][2] > 0){
      $subexp_str .= "p" . $subexp_arr_ref->[$i][2] . "x";
    }
    elsif ($subexp_arr_ref->[$i][2] < 0 and $subexp_arr_ref->[$i][2] > -1000){
      $subexp_str .= "seqf" . abs($subexp_arr_ref->[$i][2]) . "x";
    }
    elsif ($subexp_arr_ref->[$i][2] <= -1000) {
      $subexp_str .= "exp" . abs($subexp_arr_ref->[$i][2]+1000);
    }
    #Second operand shift
    if ($subexp_arr_ref->[$i][3] > 0){
      $subexp_str .= "<<<" . $subexp_arr_ref->[$i][3] . ") );";
    }
    else{
      $subexp_str .= ") );"
    }
    printf $fid_ver "%s \n", $subexp_str;
  }
  printf $fid_ver "\n";

  #Output Realizations
  printf $fid_ver "// Realization of Outputs \n"; 
  for (my $i=0; $i<$coef_cnt; $i++){
    printf $fid_ver "assign y_out%d = (", $i;
    if ($num_cnt_arr_ref->[$i]){
      for (my $j=0; $j<$num_cnt_arr_ref->[$i]; $j++){
        if ($num_val_mat_ref->[$i][$j] > 0){
          if ($num_shift_mat_ref->[$i][$j]){
            printf $fid_ver " (p%dx<<<%d)", $num_val_mat_ref->[$i][$j], $num_shift_mat_ref->[$i][$j];
          }
          else{
            printf $fid_ver " (p%dx)", $num_val_mat_ref->[$i][$j];
          }
        }
        elsif ($num_val_mat_ref->[$i][$j] < 0 and $num_val_mat_ref->[$i][$j] > -1000) {
          if ($num_shift_mat_ref->[$i][$j]){
            printf $fid_ver " (seqf%dx<<<%d)", abs($num_val_mat_ref->[$i][$j]), $num_shift_mat_ref->[$i][$j];
          }
          else{
            printf $fid_ver " (seqf%dx)", abs($num_val_mat_ref->[$i][$j]);
          }
        }
        elsif ($num_val_mat_ref->[$i][$j] <= -1000) {
          if ($num_shift_mat_ref->[$i][$j]){
            printf $fid_ver " (exp%d<<<%d)", abs($num_val_mat_ref->[$i][$j]+1000), $num_shift_mat_ref->[$i][$j];
          }
          else{
            printf $fid_ver " (exp%d)", abs($num_val_mat_ref->[$i][$j]+1000);
          }
        }

        if ($j<$num_cnt_arr_ref->[$i]-1){
          printf $fid_ver " +";
        }
        else{
          printf $fid_ver " ); \n";
        }
      }
    }
    else{
      printf $fid_ver " 'd0 ); \n"
    }
  }
  printf $fid_ver "\n";

  #MCM Module
  if ($mcm_coef_cnt){
    printf $fid_ver "// Declaration of the MCM Module \n"; 
    printf $fid_ver "%s %s_ins( \n", $module_mcm, $module_mcm;
    for (my $i=0; $i<$mcm_coef_cnt; $i++){
      printf $fid_ver "  .p%dx(p%dx), \n", $mcm_coef_arr_ref->[$i], $mcm_coef_arr_ref->[$i];
    }
    printf $fid_ver "  .x1(x_in)\n";
    printf $fid_ver "); \n";
    printf $fid_ver "\n";
  }

  printf $fid_ver "endmodule \n";

  close ($fid_ver);

  return (\@out_width_arr);
}

sub shift_coef{
  my ($out_width, $the_shift, $coef_width, $coef_arr_ref) = @_;

  my @the_partial = ();
  for (my $i=0; $i<$out_width; $i++){
    if ($i < $the_shift){
      $the_partial[$i] = 0;
    }
    elsif ($i >= $the_shift and $i < $coef_width+$the_shift){
      $the_partial[$i] = $coef_arr_ref->[$i-$the_shift];
    }
    elsif ($i >= $coef_width+$the_shift){
      $the_partial[$i] = 0;
    }
  }

  return (\@the_partial);
}

sub add_partial{
  my ($out_width, $partial_one_ref, $partial_two_ref) = @_;

  my @the_sum = ();
  my $the_carry = 0;

  for (my $i=0; $i<$out_width; $i++){
    my $partial_sum = $partial_one_ref->[$i] + $partial_two_ref->[$i] + $the_carry;
    $the_carry = POSIX::floor($partial_sum / 2);
    $the_sum[$i] = $partial_sum % 2;
  }

  return (\@the_sum);
}

sub twoscomplement{
  my ($out_width, $out_rep_ref) = @_;

  my @comp_arr = ();
  my @one_arr = ();

  for (my $i=0; $i<$out_width; $i++){
    if ($i){
      $one_arr[$i] = 0;
    }
    else{
      $one_arr[$i] = 1;
    }

    if ($out_rep_ref->[$i] == 0){
      $comp_arr[$i] = 1;
    }
    elsif ($out_rep_ref->[$i] == 1){
      $comp_arr[$i] = 0;
    }
  }

  my ($twoscomp_rep_ref) = add_partial($out_width, \@comp_arr, \@one_arr);

  return ($twoscomp_rep_ref);
}

sub compute_test_output{
  my ($coef_width, $coef_arr_ref, $out_width, $in_rep_ref, $the_in) = @_;

  my @partial_one = ();
  my @partial_two = ();
  my $partial_one_ref = \@partial_one;
  my $partial_two_ref = \@partial_two;

  my @out_rep = ();
  my $out_rep_ref = \@out_rep;
  for (my $i=0; $i<$out_width; $i++){
    $out_rep_ref->[$i] = 0;
  }

  my ($coef_bin_width, $coef_bin_ref) = hex2bin($coef_width, $coef_arr_ref);

  my $one_cnt = 0;
  for (my $i=0; $i<$in_width; $i++){
    if ($in_rep_ref->[$i] == 1){
      $one_cnt++;

      if ($one_cnt == 1){
        ($partial_one_ref) = shift_coef($out_width, $i, $coef_bin_width, $coef_bin_ref);
      }
      elsif ($one_cnt == 2){
        ($partial_two_ref) = shift_coef($out_width, $i, $coef_bin_width, $coef_bin_ref);
        ($out_rep_ref) = add_partial($out_width, $partial_one_ref, $partial_two_ref);
      }
      else{
        ($partial_one_ref) = shift_coef($out_width, $i, $coef_bin_width, $coef_bin_ref);
        ($out_rep_ref) = add_partial($out_width, $partial_one_ref, $out_rep_ref);
      }
    }
  }

  if ($one_cnt == 1){
    $out_rep_ref = $partial_one_ref;
  }
 
  if ($the_in < 0){
    $out_rep_ref = twoscomplement($out_width, $out_rep_ref);
  }

  my ($hex_width, $out_hex_ref) = bin2hex($out_width, $out_rep_ref);
  
  return ($hex_width, $out_hex_ref);
}

sub generate_test_inputs{
  my ($file_in, $file_out, $coef_cnt, $coef_width_arr_ref, $coef_ref_arr_ref, $out_width_arr_ref) = @_;

  open (my $fid_in, '>', $file_in);
  open (my $fid_out, '>', $file_out);

  my $up_limit = $is_signed ? 2**($in_width-1)-1 : 2**$in_width-1;
  my $down_limit = $is_signed ? (-1)*2**($in_width-1) : 0;

  my $test_cnt;
  my $is_exh=0;
  if (2**$in_width <= $no_test){
    $test_cnt = 2**$in_width;
    $is_exh = 1;
  }
  else{
    $test_cnt = $no_test;
  }

  #EXHAUSTIVE WAY
  if ($is_exh){
    for (my $the_in=$down_limit; $the_in<=$up_limit; $the_in++){

      my ($in_rep_ref) = int2sign($the_in, $in_width);
      for (my $i=$in_width-1; $i>=0; $i--){
        printf $fid_in "%0d", $in_rep_ref->[$i];
      }
      printf $fid_in "\n";

      #Absolute value for the shift-adds
      #In the compute_test_output function twos complement is used to obtain the correct output
      if ($the_in < 0){
        ($in_rep_ref) = int2sign(abs($the_in), $in_width);
      }

      for (my $j=0; $j<$coef_cnt; $j++){
        my $coef_arr_ref = $coef_ref_arr_ref->[$j];
        my $coef_width = $coef_width_arr_ref->[$j];
        my $out_width = $out_width_arr_ref->[$j];

        my ($out_hex_width, $out_hex_ref) = compute_test_output($coef_width, $coef_arr_ref, $out_width, $in_rep_ref, $the_in);
        
        for (my $k=$out_hex_width-1; $k>=0; $k--){
          printf $fid_out "%0s", $out_hex_ref->[$k];
        }
      }
      printf $fid_out "\n";
    }
  }
  #RANDOM WAY
  else{
    for (my $i=0; $i<$test_cnt; $i++){
      my $the_in = (int(rand(2)) == 0) ? int(rand($up_limit+1)) : (-1)*int(rand(abs($down_limit+1)));

      my ($in_rep_ref) = int2sign($the_in, $in_width);
      for (my $i=$in_width-1; $i>=0; $i--){
        printf $fid_in "%0d", $in_rep_ref->[$i];
      }
      printf $fid_in "\n";
      
      #Absolute value for the shift-adds
      #In the compute_test_output function twos complement is used to obtain the correct output
      if ($the_in < 0){
        ($in_rep_ref) = int2sign(abs($the_in), $in_width);
      }

      for (my $j=0; $j<$coef_cnt; $j++){
        my $coef_arr_ref = $coef_ref_arr_ref->[$j];
        my $coef_width = $coef_width_arr_ref->[$j];
        my $out_width = $out_width_arr_ref->[$j];

        my ($out_hex_width, $out_hex_ref) = compute_test_output($coef_width, $coef_arr_ref, $out_width, $in_rep_ref, $the_in);
        
        for (my $k=$out_hex_width-1; $k>=0; $k--){
          printf $fid_out "%0s", $out_hex_ref->[$k];
        }
      }
      printf $fid_out "\n";
    }
  }

  close ($fid_in);
  close ($fid_out);

  return ($test_cnt);
}

sub generate_testbench{
  my ($file_dir, $file_name, $coef_cnt, $coef_width_arr_ref, $coef_ref_arr_ref, $out_width_arr_ref) = @_;

  my $signed_str = $is_signed ? "signed " : "";

  my $the_msb;
  my $the_lsb;
  my $tot_out_width = 0;
  for (my $i=0; $i<$coef_cnt; $i++){
    $tot_out_width += $out_width_arr_ref->[$i];
  }

  if ($the_verb > 0){print "[INFO] Generating the testbench in Verilog... \n";}

  my $file_in = $file_name . ".inputs";
  my $file_out = $file_name . ".outputs";
  my $file_name_in = $file_dir . $file_name . ".inputs";
  my $file_name_out = $file_dir . $file_name . ".outputs";

  my ($test_cnt) = generate_test_inputs($file_name_in, $file_name_out, $coef_cnt, $coef_width_arr_ref, $coef_ref_arr_ref, $out_width_arr_ref);
  
  my $module_tb = $file_name . "_tb";
  my $file_tb = $file_dir .$file_name . "_tb.v";

  open (my $fid_tb, '>', $file_tb);

  printf $fid_tb "module %s (); \n", $module_tb;
  printf $fid_tb "\n";

  printf $fid_tb "integer test_index, out_index; \n";
  printf $fid_tb "reg [%0d:0] test_in_reg [0:%0d]; \n", $in_width-1, $test_cnt-1;
  printf $fid_tb "reg [%0d:0] test_out_reg [0:%0d]; \n", $tot_out_width-1, $test_cnt-1;
  printf $fid_tb "\n";
  printf $fid_tb "reg %s[%0d:0] x_in; \n", $signed_str, $in_width-1;
  for (my $i=0; $i<$coef_cnt; $i++){
    printf $fid_tb "wire %s[%0d:0] y_out%d; \n", $signed_str, $out_width_arr_ref->[$i]-1, $i;
  }
  printf $fid_tb "\n";
  $the_msb = $tot_out_width-1;
  for (my $i=0; $i<$coef_cnt; $i++){
    $the_lsb = $the_msb - $out_width_arr_ref->[$i] + 1;
    printf $fid_tb "reg %s[%0d:%d] test_out%d; \n", $signed_str, $the_msb, $the_lsb, $i;
    $the_msb = $the_lsb - 1;
  }
  printf $fid_tb "\n";

  printf $fid_tb "initial begin \n";
  printf $fid_tb "  \$readmemb(\"%0s\", test_in_reg); \n", $file_in;
  printf $fid_tb "  \$readmemh(\"%0s\", test_out_reg); \n", $file_out;
  printf $fid_tb "\n";
  printf $fid_tb "  // Run the simulation over the test inputs \n";
  printf $fid_tb "  for (test_index=0; test_index<%0d; test_index=test_index+1) begin \n", $test_cnt;
  printf $fid_tb "    x_in = test_in_reg[test_index][%0d:0]; \n", $in_width-1;
  printf $fid_tb "\n";
  printf $fid_tb "    \#10; \n";
  printf $fid_tb "\n";
  $the_msb = $tot_out_width-1;
  for (my $i=0; $i<$coef_cnt; $i++){
    $the_lsb = $the_msb - $out_width_arr_ref->[$i] + 1;
    printf $fid_tb "    test_out%0d = test_out_reg[test_index][%0d:%0d]; \n", $i, $the_msb, $the_lsb;
    $the_msb = $the_lsb - 1;
    printf $fid_tb "    if (test_out%0d !== y_out%0d) begin \n", $i, $i;
    printf $fid_tb "      \$display(\"[ERROR] The output%d is not the same as the expected on the %%d test pattern!\", test_index); \n", $i;
    printf $fid_tb "      \#10; \n";
    printf $fid_tb "      \$finish; \n";
    printf $fid_tb "    end \n";
    printf $fid_tb "\n";
  }
  printf $fid_tb "  end \n";
  printf $fid_tb "\n";
  printf $fid_tb "  \$display(\"[INFO] Large constant multiplication design has just been verified!\"); \n";
  printf $fid_tb "  \$stop; \n";
  printf $fid_tb "end \n";
  printf $fid_tb "\n";

  ## Writing the DUT
  printf $fid_tb "%s %s( \n", $file_name, $file_name;
  for (my $i=0; $i<$coef_cnt; $i++){
    printf $fid_tb "    .y_out%0d(y_out%0d), \n", $i, $i;
  }
  printf $fid_tb "    .x_in(x_in) \n";
  printf $fid_tb ");\n";
  printf $fid_tb "\n";

  printf $fid_tb "endmodule \n";

  close $fid_tb;
}

sub determine_alltwoterm_common_subexpressions{
  my ($coef_cnt, $num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref) = @_;

  my $tt_exp_cnt = 0;
  my @tt_exp_mat = ();
  my @tt_exp_step_arr = ();

  my $max_noc = 0;
  my $max_noc_ind = -1;
  my $max_noc_step = 9**9**9;
  my $max_noc_width = 9**9**9;

  my @tt_arr = ();
  my $tt_step = 0;
  my $tt_width = 0;
  my $min_shift = 0;

  for (my $i=0; $i<$coef_cnt; $i++){
    if ($num_cnt_arr_ref->[$i] > 2){
      for (my $j=0; $j<$num_cnt_arr_ref->[$i]-1; $j++){
        for (my $k=$j+1; $k<$num_cnt_arr_ref->[$i]; $k++){
          $min_shift = min_find2($num_shift_mat_ref->[$i][$j], $num_shift_mat_ref->[$i][$k]);
          $tt_width = max_find2($num_width_mat_ref->[$i][$j]+$num_shift_mat_ref->[$i][$j]-$min_shift, $num_width_mat_ref->[$i][$k]+$num_shift_mat_ref->[$i][$k]-$min_shift);
          $tt_step = max_find2($num_step_mat_ref->[$i][$j], $num_step_mat_ref->[$i][$k])+1;
          
          $tt_arr[0] = $num_val_mat_ref->[$i][$j];
          $tt_arr[1] = $num_shift_mat_ref->[$i][$j] - $min_shift;
          $tt_arr[2] = $num_val_mat_ref->[$i][$k];
          $tt_arr[3] = $num_shift_mat_ref->[$i][$k] - $min_shift;
          $tt_arr[4] = $tt_width+1;

          my $tt_exp_ind = is_array_inside_matrix(4, \@tt_arr, $tt_exp_cnt, \@tt_exp_mat);

          if ($tt_exp_ind == -1){
            $tt_exp_step_arr[$tt_exp_cnt] = $tt_step;
            $tt_exp_mat[$tt_exp_cnt][0] = $tt_arr[0];
            $tt_exp_mat[$tt_exp_cnt][1] = $tt_arr[1];
            $tt_exp_mat[$tt_exp_cnt][2] = $tt_arr[2];
            $tt_exp_mat[$tt_exp_cnt][3] = $tt_arr[3];
            $tt_exp_mat[$tt_exp_cnt][4] = $tt_arr[4];
            $tt_exp_mat[$tt_exp_cnt][5] = 1;
            $tt_exp_mat[$tt_exp_cnt][6] = $i;
            $tt_exp_mat[$tt_exp_cnt][7] = $j;
            $tt_exp_mat[$tt_exp_cnt][8] = $k;
            $tt_exp_cnt++;
          }
          else{
            if (does_subexp_overlap($i, $j, $k, $tt_exp_ind, \@tt_exp_mat) == 0){
              $tt_exp_mat[$tt_exp_ind][5]++;
              $tt_exp_mat[$tt_exp_ind][ 3*($tt_exp_mat[$tt_exp_ind][5]+1)   ] = $i;
              $tt_exp_mat[$tt_exp_ind][ 3*($tt_exp_mat[$tt_exp_ind][5]+1)+1 ] = $j;
              $tt_exp_mat[$tt_exp_ind][ 3*($tt_exp_mat[$tt_exp_ind][5]+1)+2 ] = $k;

              #Update the maximum occurrence
              if ($cse_aim eq "width"){
                if ($max_noc < $tt_exp_mat[$tt_exp_ind][5] or ($tt_exp_mat[$tt_exp_ind][5] == $max_noc and $tt_exp_mat[$tt_exp_ind][4] < $max_noc_width)){
                  $max_noc_width = $tt_exp_mat[$tt_exp_ind][4];
                  $max_noc = $tt_exp_mat[$tt_exp_ind][5];
                  $max_noc_ind = $tt_exp_ind;
                  $max_noc_step = $tt_step;
                }
              }
              elsif ($cse_aim eq "step"){
                if ($max_noc < $tt_exp_mat[$tt_exp_ind][5] or ($tt_exp_mat[$tt_exp_ind][5] == $max_noc and $tt_step < $max_noc_step)){
                  $max_noc_width = $tt_exp_mat[$tt_exp_ind][4];
                  $max_noc = $tt_exp_mat[$tt_exp_ind][5];
                  $max_noc_ind = $tt_exp_ind;
                  $max_noc_step = $tt_step;
                }
              }
            }
          }
        }
      }
    }
  }

  return ($max_noc, $max_noc_ind, $max_noc_step, $tt_exp_cnt, \@tt_exp_mat, \@tt_exp_step_arr);
}

sub determine_twoterm_common_subexpressions{
  my ($coef_cnt, $num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref) = @_;

  my $tt_exp_cnt = 0;
  my @tt_exp_mat = ();

  my $max_noc = 0;
  my @tt_arr = ();
  my $tt_step = 0;
  my $tt_width = 0;
  my $min_shift = 0;
  my $max_noc_ind = -1;
  my @max_noc_pos = ();
  my @max_noc_subexp = ();
  my $max_noc_step = 9**9**9;
  my $max_noc_width = 9**9**9;

  for (my $i=0; $i<$coef_cnt; $i++){
    if ($num_cnt_arr_ref->[$i] > 2){
      for (my $j=0; $j<$num_cnt_arr_ref->[$i]-1; $j++){
        for (my $k=$j+1; $k<$num_cnt_arr_ref->[$i]; $k++){
          $min_shift = min_find2($num_shift_mat_ref->[$i][$j], $num_shift_mat_ref->[$i][$j]);
          $tt_width = max_find2($num_width_mat_ref->[$i][$j]+$num_shift_mat_ref->[$i][$j]-$min_shift, $num_width_mat_ref->[$i][$k]+$num_shift_mat_ref->[$i][$k]-$min_shift);
          $tt_step = max_find2($num_step_mat_ref->[$i][$j], $num_step_mat_ref->[$i][$k])+1;
          
          $tt_arr[0] = $num_val_mat_ref->[$i][$j];
          $tt_arr[1] = $num_shift_mat_ref->[$i][$j] - $min_shift;
          $tt_arr[2] = $num_val_mat_ref->[$i][$k];
          $tt_arr[3] = $num_shift_mat_ref->[$i][$k] - $min_shift;
          $tt_arr[4] = $tt_width+1;

          my $tt_exp_ind = is_array_inside_matrix(4, \@tt_arr, $tt_exp_cnt, \@tt_exp_mat);

          if ($tt_exp_ind == -1){
            $tt_exp_mat[$tt_exp_cnt][0] = $tt_arr[0];
            $tt_exp_mat[$tt_exp_cnt][1] = $tt_arr[1];
            $tt_exp_mat[$tt_exp_cnt][2] = $tt_arr[2];
            $tt_exp_mat[$tt_exp_cnt][3] = $tt_arr[3];
            $tt_exp_mat[$tt_exp_cnt][4] = $tt_arr[4];
            $tt_exp_mat[$tt_exp_cnt][5] = 1;
            $tt_exp_mat[$tt_exp_cnt][6] = $i;
            $tt_exp_mat[$tt_exp_cnt][7] = $j;
            $tt_exp_mat[$tt_exp_cnt][8] = $k;
            $tt_exp_cnt++;
          }
          else{
            if (does_subexp_overlap($i, $j, $k, $tt_exp_ind, \@tt_exp_mat) == 0){
              $tt_exp_mat[$tt_exp_ind][5]++;
              $tt_exp_mat[$tt_exp_ind][ 3*($tt_exp_mat[$tt_exp_ind][5]+1)   ] = $i;
              $tt_exp_mat[$tt_exp_ind][ 3*($tt_exp_mat[$tt_exp_ind][5]+1)+1 ] = $j;
              $tt_exp_mat[$tt_exp_ind][ 3*($tt_exp_mat[$tt_exp_ind][5]+1)+2 ] = $k;

              if ($cse_aim eq "width"){
                if ($tt_exp_mat[$tt_exp_ind][5] > $max_noc or ($tt_exp_mat[$tt_exp_ind][5] == $max_noc and $tt_exp_mat[$tt_exp_ind][4] < $max_noc_width)){
                  $max_noc_width = $tt_exp_mat[$tt_exp_ind][4];
                  $max_noc = $tt_exp_mat[$tt_exp_ind][5];
                  $max_noc_ind = $tt_exp_ind;
                  $max_noc_step = $tt_step;
                }
              }
              elsif ($cse_aim eq "step"){
                if ($tt_exp_mat[$tt_exp_ind][5] > $max_noc or ($tt_exp_mat[$tt_exp_ind][5] == $max_noc and $tt_step < $max_noc_step)){
                  $max_noc_width = $tt_exp_mat[$tt_exp_ind][4];
                  $max_noc = $tt_exp_mat[$tt_exp_ind][5];
                  $max_noc_ind = $tt_exp_ind;
                  $max_noc_step = $tt_step;
                }
              }
            }
          }
        }
      }
    }
  }

  if ($max_noc > 1){
    $max_noc_subexp[0] = $tt_exp_mat[$max_noc_ind][0];
    $max_noc_subexp[1] = $tt_exp_mat[$max_noc_ind][1];
    $max_noc_subexp[2] = $tt_exp_mat[$max_noc_ind][2];
    $max_noc_subexp[3] = $tt_exp_mat[$max_noc_ind][3];
    $max_noc_subexp[4] = $tt_exp_mat[$max_noc_ind][4];

    for (my $i=0; $i<$tt_exp_mat[$max_noc_ind][5]; $i++){
      $max_noc_pos[3*$i] = $tt_exp_mat[$max_noc_ind][3*($i+2)];
      $max_noc_pos[3*$i+1] = $tt_exp_mat[$max_noc_ind][3*($i+2)+1];
      $max_noc_pos[3*$i+2] = $tt_exp_mat[$max_noc_ind][3*($i+2)+2];
    }
  }

  return ($max_noc, $max_noc_step, \@max_noc_subexp, \@max_noc_pos);
}

sub find_next_subexpression{
  my ($coef_cnt, $num_cnt_arr_ref, $ttexp_cnt, $ttexp_mat_ref, $ttexp_step_arr_ref, $replace_mat_ref) = @_;

  my $coef_ind;
  my $pos_one;
  my $pos_two;

  my $max_noc = 0;
  my $max_noc_ind = -1;
  my $max_noc_step = 9**9**9;
  my $max_noc_width = 9**9**9;

  for (my $i=0; $i<$ttexp_cnt; $i++){
    if ($ttexp_mat_ref->[$i][5] > 1 and $ttexp_mat_ref->[$i][5] > $max_noc){
      my $the_noc = 0;
      for (my $j=0; $j<$ttexp_mat_ref->[$i][5]; $j++){
        $coef_ind = $ttexp_mat_ref->[$i][3*($j+2)];
        $pos_one = $ttexp_mat_ref->[$i][3*($j+2)+1];
        $pos_two = $ttexp_mat_ref->[$i][3*($j+2)+2];

        if ($replace_mat_ref->[$coef_ind][$pos_one] == 0 and $replace_mat_ref->[$coef_ind][$pos_two] == 0){
          $the_noc++;
        }
      }

      if ($cse_aim eq "width"){
        if ($the_noc > $max_noc or ($the_noc == $max_noc and $ttexp_mat_ref->[$i][4] < $max_noc_width)){
          $max_noc_step = $ttexp_step_arr_ref->[$i];
          $max_noc_width = $ttexp_mat_ref->[$i][4];
          $max_noc = $the_noc;
          $max_noc_ind = $i;
        }
      }
      elsif ($cse_aim eq "step"){
        if ($the_noc > $max_noc or ($the_noc == $max_noc and $ttexp_step_arr_ref->[$i] < $max_noc_step)){
          $max_noc_step = $ttexp_step_arr_ref->[$i];
          $max_noc_width = $ttexp_mat_ref->[$i][4];
          $max_noc = $the_noc;
          $max_noc_ind = $i;
        }
      }
    }
  }

  return ($max_noc, $max_noc_ind, $max_noc_step);
}

sub replace_alltwoterm_common_subexpression{
  my ($no_iter, $coef_cnt, $num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref, $max_noc, $max_noc_ind, $max_noc_step, $ttexp_cnt, $ttexp_mat_ref, $ttexp_step_arr_ref, $subexp_cnt, $subexp_arr_ref) = @_;
 
  my $pos_one;
  my $pos_two;
  my $coef_ind;

  my @new_num_cnt_arr = ();
  my @new_num_val_mat = ();
  my @new_num_step_mat = ();
  my @new_num_shift_mat = ();
  my @new_num_width_mat = ();

  my @replace_mat = ();
  my @replace_step_mat = ();
  my @replace_width_mat = ();
  for (my $i=0; $i<$coef_cnt; $i++){
    for (my $j=0; $j<$num_cnt_arr_ref->[$i]; $j++){
      $replace_mat[$i][$j] = 0;
      $replace_width_mat[$i][$j] = 0;
    }
  }

  while (1){
    for (my $i=0; $i<$ttexp_mat_ref->[$max_noc_ind][5]; $i++){
      $coef_ind = $ttexp_mat_ref->[$max_noc_ind][3*($i+2)];
      $pos_one = $ttexp_mat_ref->[$max_noc_ind][3*($i+2)+1];
      $pos_two = $ttexp_mat_ref->[$max_noc_ind][3*($i+2)+2];

      if ($replace_mat[$coef_ind][$pos_one] == 0 and $replace_mat[$coef_ind][$pos_two] == 0){
        $replace_mat[$coef_ind][$pos_one] = ($subexp_cnt+1);
        $replace_mat[$coef_ind][$pos_two] = (-1)*($subexp_cnt+1);
        $replace_step_mat[$coef_ind][$pos_one] = $max_noc_step;
        $replace_width_mat[$coef_ind][$pos_one] = $ttexp_mat_ref->[$max_noc_ind][4];
      }
    }
    
    #Add the subexpression 
    for (my $i=0; $i<5; $i++){
      $subexp_arr_ref->[$subexp_cnt][$i] = $ttexp_mat_ref->[$max_noc_ind][$i];
    }
    $subexp_cnt++;

    ($max_noc, $max_noc_ind, $max_noc_step) = find_next_subexpression($coef_cnt, $num_cnt_arr_ref, $ttexp_cnt, $ttexp_mat_ref, $ttexp_step_arr_ref, \@replace_mat);

    if ($max_noc < 2){
      last;
    }
  }

  for (my $i=0; $i<$coef_cnt; $i++){
    $new_num_cnt_arr[$i] = 0;
    for (my $j=0; $j<$num_cnt_arr_ref->[$i]; $j++){
      if ($replace_mat[$i][$j] == 0){
        $new_num_val_mat[$i][ $new_num_cnt_arr[$i] ] = $num_val_mat_ref->[$i][$j];
        $new_num_shift_mat[$i][ $new_num_cnt_arr[$i] ] = $num_shift_mat_ref->[$i][$j];
        $new_num_width_mat[$i][ $new_num_cnt_arr[$i] ] = $num_width_mat_ref->[$i][$j];
        $new_num_step_mat[$i][ $new_num_cnt_arr[$i] ] = $num_step_mat_ref->[$i][$j];
        $new_num_cnt_arr[$i]++;
      }
      elsif ($replace_mat[$i][$j] > 0){
        $new_num_val_mat[$i][ $new_num_cnt_arr[$i] ] = (-1)*1000-($replace_mat[$i][$j]-1);
        $new_num_shift_mat[$i][ $new_num_cnt_arr[$i] ] = $num_shift_mat_ref->[$i][$j];
        $new_num_width_mat[$i][ $new_num_cnt_arr[$i] ] = $replace_width_mat[$i][$j];
        $new_num_step_mat[$i][ $new_num_cnt_arr[$i] ] = $replace_step_mat[$i][$j];
        $new_num_cnt_arr[$i]++;
      }
    }
  }

  return (\@new_num_cnt_arr, \@new_num_shift_mat, \@new_num_val_mat, \@new_num_width_mat, \@new_num_step_mat, $subexp_cnt, $subexp_arr_ref);
}

sub replace_twoterm_common_subexpression{
  my ($coef_cnt, $num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref, $max_noc, $max_noc_step, $max_noc_subexp_ref, $max_noc_pos_ref, $subexp_cnt) = @_;

  my @new_num_cnt_arr = ();
  my @new_num_val_mat = ();
  my @new_num_step_mat = ();
  my @new_num_shift_mat = ();
  my @new_num_width_mat = ();

  my @replace_mat = ();
  for (my $i=0; $i<$coef_cnt; $i++){
    for (my $j=0; $j<$num_cnt_arr_ref->[$i]; $j++){
      $replace_mat[$i][$j] = 0;
    }
  }
  for (my $i=0; $i<$max_noc; $i++){
    $replace_mat[ $max_noc_pos_ref->[3*$i] ][ $max_noc_pos_ref->[3*$i+1] ] = 1;
    $replace_mat[ $max_noc_pos_ref->[3*$i] ][ $max_noc_pos_ref->[3*$i+2] ] = -1;
  }

  for (my $i=0; $i<$coef_cnt; $i++){
    $new_num_cnt_arr[$i] = 0;
    for (my $j=0; $j<$num_cnt_arr_ref->[$i]; $j++){
      if ($replace_mat[$i][$j] == 0){
        $new_num_val_mat[$i][ $new_num_cnt_arr[$i] ] = $num_val_mat_ref->[$i][$j];
        $new_num_shift_mat[$i][ $new_num_cnt_arr[$i] ] = $num_shift_mat_ref->[$i][$j];
        $new_num_width_mat[$i][ $new_num_cnt_arr[$i] ] = $num_width_mat_ref->[$i][$j];
        $new_num_step_mat[$i][ $new_num_cnt_arr[$i] ] = $num_step_mat_ref->[$i][$j];
        $new_num_cnt_arr[$i]++;
      }
      elsif ($replace_mat[$i][$j] == 1){
        $new_num_val_mat[$i][ $new_num_cnt_arr[$i] ] = (-1)*1000-$subexp_cnt;
        $new_num_shift_mat[$i][ $new_num_cnt_arr[$i] ] = $num_shift_mat_ref->[$i][$j];
        $new_num_width_mat[$i][ $new_num_cnt_arr[$i] ] = $max_noc_subexp_ref->[4];
        $new_num_step_mat[$i][ $new_num_cnt_arr[$i] ] = $max_noc_step;
        $new_num_cnt_arr[$i]++;
      }
    }
  }

  return (\@new_num_cnt_arr,\@new_num_shift_mat, \@new_num_val_mat, \@new_num_width_mat, \@new_num_step_mat);
}

sub choose_subexpression_strategy{
  my ($coef_cnt, $num_cnt_arr_ref) = @_;

  my $the_ses = "single";

  my $oper_num = 0;
  for (my $i=0; $i<$coef_cnt; $i++){
    $oper_num += $num_cnt_arr_ref->[$i];
  }

  if ($oper_num > 100){
    $the_ses = "all";
  }

  return ($the_ses);
}

sub share_common_subexpressions{
  my ($coef_cnt, $num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref) = @_;

  my $init_time = time();

  my $no_iter = 0;
  my $subexp_cnt = 0;
  my @subexp_arr = ();
  my $subexp_arr_ref = \@subexp_arr;

  if ($the_verb > 0){print "[INFO] Sharing common subexpressions... \n";}

  while (1){
    my $the_ses = "";
    if ($ses_tech eq "auto"){
      $the_ses = choose_subexpression_strategy($coef_cnt, $num_cnt_arr_ref);
    }
    else{
      $the_ses = $ses_tech;
    }

    #At each iteration a single subexpression with maximum number of occurences is eliminated
    if ($the_ses eq "single"){
      $no_iter++;
      my ($max_noc, $max_noc_step, $max_noc_subexp_ref, $max_noc_pos_ref) = determine_twoterm_common_subexpressions($coef_cnt, $num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref);
      #if ($the_verb > 1){print "[INFO] no_iter: $no_iter max_noc: $max_noc max_noc_step: $max_noc_step \n";}

      if ($max_noc > 1){
        ($num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref) = replace_twoterm_common_subexpression($coef_cnt, $num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref, $max_noc, $max_noc_step, $max_noc_subexp_ref, $max_noc_pos_ref, $subexp_cnt);
        for (my $i=0; $i<5; $i++){
          $subexp_arr_ref->[$subexp_cnt][$i] = $max_noc_subexp_ref->[$i];
        }
        $subexp_cnt++;
      }
      else{
        last;
      }
    }

    #At each iteration all independent subexpressions with maximum number of occurences is eliminated
    elsif ($the_ses eq "all"){
      $no_iter++;
      my ($max_noc, $max_noc_ind, $max_noc_step, $ttexp_cnt, $ttexp_mat_ref, $ttexp_step_arr_ref) = determine_alltwoterm_common_subexpressions($coef_cnt, $num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref);

      if ($max_noc > 1){
        ($num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref, $subexp_cnt, $subexp_arr_ref) = replace_alltwoterm_common_subexpression$no_iter, ($coef_cnt, $num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref, $max_noc, $max_noc_ind, $max_noc_step, $ttexp_cnt, $ttexp_mat_ref, $ttexp_step_arr_ref, $subexp_cnt, $subexp_arr_ref);
      }
      else{
        last;
      }
    }
  }

  my $last_time = time()-$init_time;

  return ($last_time, $subexp_cnt, $subexp_arr_ref, $num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref)
}

sub determine_replace_le_ttexp{
  my ($coef_index, $subexp_cnt, $subexp_arr_ref, $num_cnt, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref, $new_num_step_arr_ref) = @_;

  my $tt_shift = 0;
  my $term_one = -1;
  my $term_two = -1;
  my $tt_org_step = -1;
  my $tt_step = 9**9**9;
  my $tt_width = 9**9**9;

  my $org_step;
  my $the_step;
  my $the_width;
  my $min_shift;

  #Determine the two-term expression
  for (my $i=0; $i<$num_cnt-1; $i++){
    for (my $j=$i+1; $j<$num_cnt; $j++){
      $min_shift = 0;
      $the_step = max_find2($new_num_step_arr_ref->[$i], $new_num_step_arr_ref->[$j])+1;
      $org_step = max_find2($num_step_mat_ref->[$coef_index][$i], $num_step_mat_ref->[$coef_index][$j])+1;
      $the_width = max_find2($num_width_mat_ref->[$coef_index][$i]+$num_shift_mat_ref->[$coef_index][$i]-$min_shift, $num_width_mat_ref->[$coef_index][$j]+$num_shift_mat_ref->[$coef_index][$j]-$min_shift)+1;

      if ($sle_aim eq "area"){
        if ($the_width < $tt_width or ($the_width == $tt_width and $the_step < $tt_step)){
          $term_one = $i;
          $term_two = $j;
          $tt_step = $the_step;
          $tt_width = $the_width;
          $tt_shift = $min_shift;
          $tt_org_step = $org_step;
        }
      }
      elsif ($sle_aim eq "delay"){
        if ($the_step < $tt_step or ($the_step == $tt_step and $the_width < $tt_width)){
          $term_one = $i;
          $term_two = $j;
          $tt_step = $the_step;
          $tt_width = $the_width;
          $tt_shift = $min_shift;
          $tt_org_step = $org_step;
        }
      }
    }
  }

  #Add to the subexpression list
  $subexp_arr_ref->[$subexp_cnt][0] = $num_val_mat_ref->[$coef_index][$term_one];
  $subexp_arr_ref->[$subexp_cnt][1] = $num_shift_mat_ref->[$coef_index][$term_one]-$tt_shift;
  $subexp_arr_ref->[$subexp_cnt][2] = $num_val_mat_ref->[$coef_index][$term_two];
  $subexp_arr_ref->[$subexp_cnt][3] = $num_shift_mat_ref->[$coef_index][$term_two]-$tt_shift;
  $subexp_arr_ref->[$subexp_cnt][4] = $tt_width;
  
  #Update the linear equation
  my $new_num_cnt = 0;
  for (my $i=0; $i<$num_cnt; $i++){
    if ($i == $term_one){
      $num_shift_mat_ref->[$coef_index][$new_num_cnt] = $tt_shift;
      $num_val_mat_ref->[$coef_index][$new_num_cnt] = (-1)*1000-$subexp_cnt;
      $num_width_mat_ref->[$coef_index][$new_num_cnt] = $tt_width;
      $new_num_step_arr_ref->[$new_num_cnt] = $tt_step;
      $num_step_mat_ref->[$coef_index][$new_num_cnt] = $tt_org_step;
      $new_num_cnt++;
    }
    elsif ($i != $term_two){
      $num_shift_mat_ref->[$coef_index][$new_num_cnt] = $num_shift_mat_ref->[$coef_index][$i];
      $num_val_mat_ref->[$coef_index][$new_num_cnt] = $num_val_mat_ref->[$coef_index][$i];
      $num_width_mat_ref->[$coef_index][$new_num_cnt] = $num_width_mat_ref->[$coef_index][$i];
      $new_num_step_arr_ref->[$new_num_cnt] = $new_num_step_arr_ref->[$i];
      $num_step_mat_ref->[$coef_index][$new_num_cnt] = $num_step_mat_ref->[$coef_index][$i];
      $new_num_cnt++;
    }
  }

  $subexp_cnt++;

  return ($subexp_cnt, $subexp_arr_ref, $new_num_cnt, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref, $new_num_step_arr_ref);
}

sub identify_replace_le_ttexp{
  my ($coef_index, $subexp_cnt, $subexp_arr_ref, $num_cnt, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref, $one_two_term_arr_ref) = @_;

  my $term_one = $one_two_term_arr_ref->[0];
  my $term_two = $one_two_term_arr_ref->[1];
  my $tt_shift = 0;
  my $tt_org_step = max_find2($num_step_mat_ref->[$coef_index][$term_one], $num_step_mat_ref->[$coef_index][$term_two])+1;
  my $tt_width =  max_find2($num_width_mat_ref->[$coef_index][$term_one]+$num_shift_mat_ref->[$coef_index][$term_one]-$tt_shift, $num_width_mat_ref->[$coef_index][$term_two]+$num_shift_mat_ref->[$coef_index][$term_two]-$tt_shift)+1;

  #Add to the subexpression list
  $subexp_arr_ref->[$subexp_cnt][0] = $num_val_mat_ref->[$coef_index][$term_one];
  $subexp_arr_ref->[$subexp_cnt][1] = $num_shift_mat_ref->[$coef_index][$term_one]-$tt_shift;
  $subexp_arr_ref->[$subexp_cnt][2] = $num_val_mat_ref->[$coef_index][$term_two];
  $subexp_arr_ref->[$subexp_cnt][3] = $num_shift_mat_ref->[$coef_index][$term_two]-$tt_shift;
  $subexp_arr_ref->[$subexp_cnt][4] = $tt_width;
  
  #Update the linear equation
  my $new_num_cnt = 0;
  for (my $i=0; $i<$num_cnt; $i++){
    if ($i == $term_one){
      $num_shift_mat_ref->[$coef_index][$new_num_cnt] = $tt_shift;
      $num_val_mat_ref->[$coef_index][$new_num_cnt] = (-1)*1000-$subexp_cnt;
      $num_width_mat_ref->[$coef_index][$new_num_cnt] = $tt_width;
      $num_step_mat_ref->[$coef_index][$new_num_cnt] = $tt_org_step;
      $new_num_cnt++;
    }
    elsif ($i != $term_two){
      $num_shift_mat_ref->[$coef_index][$new_num_cnt] = $num_shift_mat_ref->[$coef_index][$i];
      $num_val_mat_ref->[$coef_index][$new_num_cnt] = $num_val_mat_ref->[$coef_index][$i];
      $num_width_mat_ref->[$coef_index][$new_num_cnt] = $num_width_mat_ref->[$coef_index][$i];
      $num_step_mat_ref->[$coef_index][$new_num_cnt] = $num_step_mat_ref->[$coef_index][$i];
      $new_num_cnt++;
    }
  }

  $subexp_cnt++;

  return ($subexp_cnt, $subexp_arr_ref, $new_num_cnt, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref);
}

sub synthesize_linear_equation{
  my ($coef_cnt, $subexp_cnt, $subexp_arr_ref, $num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref) = @_;

  if ($the_verb > 0){print "[INFO] Synthesizing the linear equations... \n";}

  for (my $i=0; $i<$coef_cnt; $i++){
    #The original adder-step is dominated by the length of subexpressions and leads to unreasonable results
    my @new_num_step_arr = ();
    for (my $j=0; $j<$num_cnt_arr_ref->[$i]; $j++){
      $new_num_step_arr[$j] = 1;
    }
    my $new_num_step_arr_ref = \@new_num_step_arr;

    #In each linear equation find and replace a two term expression based on the aim - area or delay
    while ($num_cnt_arr_ref->[$i] > 2){
      ($subexp_cnt, $subexp_arr_ref, $num_cnt_arr_ref->[$i], $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref, $new_num_step_arr_ref) = determine_replace_le_ttexp($i, $subexp_cnt, $subexp_arr_ref, $num_cnt_arr_ref->[$i], $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref, $new_num_step_arr_ref);
    }  
  }

  return ($subexp_cnt, $subexp_arr_ref, $num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref);
}

sub compute_adder_step{
  my ($coef_cnt, $num_step_mat_ref, $zero_coef_arr_ref) = @_;

  my $the_step;
  my $adder_step = 0;

  for (my $i=0; $i<$coef_cnt; $i++){
    if ($zero_coef_arr_ref->[$i] == 0){
      my $step_one = defined($num_step_mat_ref->[$i][0]) ? $num_step_mat_ref->[$i][0] : 0;
      my $step_two = defined($num_step_mat_ref->[$i][1]) ? $num_step_mat_ref->[$i][1] : 0;
      if ($step_one and $step_two){
        $the_step = max_find2($step_one, $step_two)+1;
      }
      elsif ($step_one){
        $the_step = $step_one;
      }
      elsif ($step_two){
        $the_step = $step_two;
      }
      else{
        $the_step = 1;
      }

      if ($the_step > $adder_step){
        $adder_step = $the_step;
      }
    }
  }

  return ($adder_step);
}

sub main_part{
  my ($local_coef_file) = @_;

  my $init_time = time();
  
  my $mcm_time = 0;
  my $cse_time = 0;
  my $adder_step = 0;
  my $total_time = 0;
  my $no_tot_oper = 0;
  my $no_cse_oper = 0;
  my $no_mcm_oper = 0;
  my $no_sum_oper = 0;

  ##Extract the file name and directory
  my ($file_name, $file_dir) = extract_file_name_directory($local_coef_file);

  #Extend the file name with number of hex digits in the partition
  if ($the_arch == 0){
    $file_name .= "_a0_iw" . $in_width;
  }
  else{
    $file_name .= "_a1d" . $dig_par . "t" . $par_tech . "_iw" . $in_width . "_MCM" . $mcm_aim . "_CSE" . $cse_aim . "_SLE" . $sle_aim;
  }
  if ($is_signed){
    $file_name .= "_signed";
  }

  #Read the constants
  my ($coef_cnt, $coef_width_arr_ref, $coef_ref_arr_ref, $zero_coef_arr_ref) = read_coefs($local_coef_file);

  if ($coef_cnt){
    my $out_width_arr_ref;
    if ($the_arch == 1){
      #First-stage optimization - Multiple Constant Multiplication
      my ($mcm_oper, $mcm_cpu, $seqexp_cnt, $seqexp_arr_ref, $mcm_coef_cnt, $mcm_coef_arr_ref, $num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref) = preprocess_generate_mcm_block($file_dir, $file_name, $coef_cnt, $coef_width_arr_ref, $coef_ref_arr_ref);

      #Second-stage optimization - Common Subexpression Elimination
      my $cse_cpu = 0;
      my $subexp_cnt = 0;
      my $subexp_arr_ref;
      my $subexp_cse_cnt = 0;
      ($cse_cpu, $subexp_cnt, $subexp_arr_ref, $num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref) = share_common_subexpressions($coef_cnt, $num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref);
      $subexp_cse_cnt = $subexp_cnt;

      #Third-stage optimization - Synthesis of Linear Equations
      ($subexp_cnt, $subexp_arr_ref, $num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref) = synthesize_linear_equation($coef_cnt, $subexp_cnt, $subexp_arr_ref, $num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $num_width_mat_ref, $num_step_mat_ref);

      #Compute the adder-step
      ($adder_step) = compute_adder_step($coef_cnt, $num_step_mat_ref, $zero_coef_arr_ref);

      #Compute the total number of adders/subtractors
      my $tot_oper = $mcm_oper + $seqexp_cnt + $subexp_cnt;
      for (my $i=0; $i<$coef_cnt; $i++){
        for (my $j=0; $j<$num_cnt_arr_ref->[$i]; $j++){
          if ($num_val_mat_ref->[$i][$j]){
            $tot_oper++;
          }
        }
        if ($num_cnt_arr_ref->[$i] >= 1){
          $tot_oper--;
        }
      }
      $no_sum_oper = $tot_oper-$mcm_oper-$seqexp_cnt-$subexp_cse_cnt;
      $no_cse_oper = $subexp_cse_cnt;
      $no_tot_oper = $tot_oper;
      $no_mcm_oper = $mcm_oper;
      $mcm_time = $mcm_cpu;
      $cse_time = $cse_cpu; 

      #Describe the shift-adds design in Verilog
      ($out_width_arr_ref) = describe_sa_design_verilog($file_dir, $file_name, $no_mcm_oper, $no_cse_oper, $no_sum_oper, $no_tot_oper, $adder_step, $seqexp_cnt, $seqexp_arr_ref, $mcm_coef_cnt, $mcm_coef_arr_ref, $num_cnt_arr_ref, $num_shift_mat_ref, $num_val_mat_ref, $coef_cnt, $coef_width_arr_ref, $subexp_cnt, $subexp_cse_cnt, $subexp_arr_ref);
    }
    else{
      #Describe the design with a generic multiplier in Verilog
      ($out_width_arr_ref) = describe_gm_design_verilog($file_dir, $file_name, $coef_cnt, $coef_width_arr_ref, $coef_ref_arr_ref);
    }

    #Generate the test-bench
    generate_testbench($file_dir, $file_name, $coef_cnt, $coef_width_arr_ref, $coef_ref_arr_ref, $out_width_arr_ref);

    $total_time = time()-$init_time;
    if ($the_arch){
      printf "[INFO] Number of adders/subtractors in the MCM block: %d \n", $no_mcm_oper;
      printf "[INFO] Number of adders/subtractors in the CSE block: %d \n", $no_cse_oper;
      printf "[INFO] Number of adders/subtractors in the linear equations: %d \n", $no_sum_oper;
      printf "[INFO] Total number of adders/subtractors: %d \n", $no_tot_oper;
      printf "[INFO] Number of adder-steps: %d \n", $adder_step;
      printf "[INFO] Total MCM time: %.2f \n", $mcm_time;
      printf "[INFO] Total CSE time: %.2f \n", $cse_time;
    }
    printf "[INFO] Total CPU time: %.2f \n", $total_time;
  }
}

