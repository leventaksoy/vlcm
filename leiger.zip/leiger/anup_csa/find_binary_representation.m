function [say_digit,binary_rep] = find_binary_representation(the_number)

say_digit=0;
binary_rep=[];

if the_number~=0
    while the_number~=1
        say_digit=say_digit+1;
        remainder=mod(the_number,2);
        binary_rep(1,say_digit)=remainder;
        if remainder==0
            the_number=the_number/2;
        else
            the_number=(the_number-1)/2;
        end
    end
    say_digit=say_digit+1;
    binary_rep(1,say_digit)=1;
    say_digit=say_digit+1;
    binary_rep(1,say_digit)=0;
else
    say_digit=2;
    binary_rep=[0 0];
end
