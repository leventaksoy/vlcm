function [value] = is_divisor_inside(say_divisor,divisor_list,a_divisor)

value=0;

for i=1:say_divisor
    value=1;
    
    for j=1:3
        if a_divisor(1,j)~=divisor_list(i,j)
            value=0;
            break
        end
    end
    
    if value
        break
    end
end