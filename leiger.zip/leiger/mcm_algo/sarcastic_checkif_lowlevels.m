function [value] = sarcastic_checkif_lowlevels(unimp_level,say_imp,imp_list)

value=0;

for i=1:say_imp
    if imp_list(2,i)==unimp_level-1
        value=1;
        return
    end
end
