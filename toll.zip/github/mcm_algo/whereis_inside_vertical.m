function [the_indis] = whereis_inside_vertical(say_cons,cons_list,the_cons)

the_indis=0;

for i=1:say_cons
    if cons_list(i,1)==the_cons
        the_indis=i;
    end
end
