mcm_algo = C:/Users/levent/codes/perl/lcm/github/mex/mcm_algo
mcm_high2low = C:/Users/levent/codes/perl/lcm/github/mex/mcm_high2low
hcub_algo = C:\cygwin64\home\levent\tools\hcub\synth 
