function [max_step,say_oper,oper_list,oper_indis] = find_mcm_solution_wodc(dfs_cpu_limit, say_coef,coef_list,max_target)

max_step=0;
say_oper=0;
oper_list=[];
oper_indis=[];

if say_coef>1
    max_limit=ceil(log2(max_target));

    nzd_cost=textread('nzd_cost','%d',2^(max_limit+1));
    scm_cost=textread('scm_cost','%d',2^max_limit);

    say_unimp=say_coef-1;
    unimp_list=coef_list(1:1,2:say_coef);

    lowest_bound=say_coef-1;
    [lower_bound,lower_step]=mcm_find_lower_bound(say_coef,coef_list,nzd_cost);
    [upper_bound_approx,upper_list_approx]=mcm_find_upper_bound_approx(scm_cost,say_coef,say_unimp,max_limit,coef_list,unimp_list);
    lower_bound_heuristic=lowest_bound+2;
    upper_bound=upper_bound_approx;
    upper_list=upper_list_approx;

    min_guaranteed=1;
    if and(not(upper_bound<=lower_bound),not(upper_bound<=lower_bound_heuristic))
        fprintf('[INFO] Running the depth-first-search...\n');

        if lower_bound<lower_bound_heuristic
            lower_bound=lower_bound_heuristic;
        end

        [min_list,search_timeover]=mcm_depth_first_search(dfs_cpu_limit,max_limit,lowest_bound,lower_bound,upper_bound,say_unimp,unimp_list);

        if ~isempty(min_list)
            upper_list=min_list;
        end

        if search_timeover
            min_guaranteed=0;
        end
    end

    say_imp=1;
    imp_list=[1];

    say_unimp=length(upper_list);
    unimp_list=upper_list;
    say_unimp=say_unimp-1;
    unimp_list(:,1)=[];

    [say_oper,oper_list,oper_indis,max_step]=mcm_synthesize(max_limit,say_imp,imp_list,say_unimp,unimp_list);
end
