function [max_step,say_oper,oper_list,oper_indis] = sarcastic_synthesize(bit_width,max_level,say_ready,ready_list,say_target,target_list)

max_step=0;
say_oper=0;
oper_list=[];
oper_indis=[];

for h=1:max_level
    new_sayready=say_ready;
    new_readylist=ready_list;
    
    for i=2:1:say_target
        if target_list(2,i)==h
            is_synth=0;
            digit_unimp=ceil(log2(target_list(1,i)));

            for j=1:say_ready
                digit_imp=ceil(log2(ready_list(1,j)));

                for us=0:1:bit_width+1
                    the_partial=(2^us)*ready_list(1,j)-target_list(1,i);
                    [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);

                    if is_inside(posodd_partial,say_ready,ready_list)
                        is_synth=1;
                        say_oper=say_oper+1;
                        
                        oper_list(say_oper,1)=target_list(1,i);
                        oper_list(say_oper,2)=0;
                        oper_list(say_oper,3)=1;
                        oper_list(say_oper,4)=ready_list(1,j);
                        oper_list(say_oper,5)=us;
                        if the_partial>0
                            oper_list(say_oper,6)=-1;
                        else
                            oper_list(say_oper,6)=1;
                        end
                        oper_list(say_oper,7)=posodd_partial;
                        oper_list(say_oper,8)=the_power;
                        
                        new_sayready=new_sayready+1;
                        new_readylist(1,new_sayready)=target_list(1,i);
                    end

                    if not(is_synth)
                        the_partial=(2^us)*ready_list(1,j)+target_list(1,i);
                        [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);

                        if is_inside(posodd_partial,say_ready,ready_list)
                            is_synth=1;
                            say_oper=say_oper+1;
                            
                            oper_list(say_oper,1)=target_list(1,i);
                            oper_list(say_oper,2)=0;
                            oper_list(say_oper,3)=1;
                            oper_list(say_oper,4)=posodd_partial;
                            oper_list(say_oper,5)=the_power;
                            oper_list(say_oper,6)=-1;
                            oper_list(say_oper,7)=ready_list(1,j);
                            oper_list(say_oper,8)=us;
                            
                            new_sayready=new_sayready+1;
                            new_readylist(1,new_sayready)=target_list(1,i);
                        end
                    end

                    if is_synth
                        break
                    end
                end

%                 if not(is_synth)
%                     for us=1:1:bit_width-digit_unimp+1
%                         the_partial=ready_list(1,j)-(2^us)*target_list(1,i);
%                         [the_power,posodd_partial]=make_number_posodd(the_partial);
% 
%                         if is_inside(posodd_partial,say_ready,ready_list)
%                             is_synth=1;
%                             say_oper=say_oper+1;
%                             
%                             oper_list(say_oper,1)=target_list(1,i);
%                             oper_list(say_oper,2)=us;
%                             oper_list(say_oper,3)=1;
%                             oper_list(say_oper,4)=ready_list(1,j);
%                             oper_list(say_oper,5)=0;
%                             if the_partial>0
%                                 oper_list(say_oper,6)=-1;
%                                 fprintf(fid_result,'%6d>>%d = +%d<<0 -%d<<0\n',target_list(1,i),us,ready_list(1,j),posodd_partial);
%                             else
%                                 oper_list(say_oper,6)=1;
%                                 fprintf(fid_result,'%6d>>%d = +%d<<0 +%d<<0\n',target_list(1,i),us,ready_list(1,j),posodd_partial);
%                             end
%                             oper_list(say_oper,7)=posodd_partial;
%                             oper_list(say_oper,8)=0;
%                             
%                             new_sayready=new_sayready+1;
%                             new_readylist(1,new_sayready)=target_list(1,i);
%                         end
% 
%                         if not(is_synth)
%                             the_partial=ready_list(1,j)+(2^us)*target_list(1,i);
% 
%                             if is_inside(the_partial,say_ready,ready_list)
%                                 is_synth=1;
%                                 say_oper=say_oper+1;
%                                 
%                                 oper_list(say_oper,1)=target_list(1,i);
%                                 oper_list(say_oper,2)=us;
%                                 oper_list(say_oper,3)=-1;
%                                 oper_list(say_oper,4)=ready_list(1,j);
%                                 oper_list(say_oper,5)=0;
%                                 oper_list(say_oper,6)=1;
%                                 oper_list(say_oper,7)=posodd_partial;
%                                 oper_list(say_oper,8)=0;
% 
%                                 fprintf(fid_result,'%6d>>%d = -%d<<0 +%d<<0\n',target_list(1,i),us,ready_list(1,j),the_partial);
%                                 
%                                 new_sayready=new_sayready+1;
%                                 new_readylist(1,new_sayready)=target_list(1,i);
%                             end
%                         end
% 
%                         if is_synth
%                             break
%                         end
%                     end
%                 end

                if is_synth
                    break
                end
            end
        end
    end
    
    say_ready=new_sayready;
    ready_list=new_readylist;
end

[oper_list,oper_indis,max_step]=sarcastic_find_level(say_oper,oper_list);
