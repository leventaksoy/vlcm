function [value] = self_test(the_divisor)

value=0;
say_list=0;
the_list=[];

for i=1:3
    [power,the_number]=make_number_posodd(the_divisor(1,i));
    the_pos=where_is_inside(the_number,say_list,the_list);
    
    if not(the_pos)
        say_list=say_list+1;
        the_list(1,say_list)=the_number;
        the_list(2,say_list)=1;
    else
        the_list(2,the_pos)=the_list(2,the_pos)+1;
    end
end

if say_list==3
    value=0;
elseif say_list==2
    if or(and(the_list(1,1)==1,the_list(2,1)==1),and(the_list(1,2)==1,the_list(2,2)==1))
        value=1;
    end
elseif and(say_list==1, the_list(1,1)==1)
    value=1;
end
