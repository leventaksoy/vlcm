function count_frequency = find_frequency(the_length,the_nonzero,the_initial,a_divisor)

count_frequency=1;

if the_length>=6
    for i=1:3
        the_nonzero(2,the_initial(1,i))=count_frequency;
    end
    
    for i=1:the_length-2
        if the_nonzero(2,i)==0
            carpan=the_nonzero(1,i)/a_divisor(1,1);
            the_divisor=carpan*a_divisor;
            first_konum=i;
            
            second_konum=0;
            for j=i+1:1:the_length-1
                if not(the_nonzero(2,j))
                    if the_nonzero(1,j)==the_divisor(1,2)
                        second_konum=j;
                        break
                    end
                end
            end
            
            if second_konum
                third_konum=0;
                for j=second_konum+1:1:the_length
                    if not(the_nonzero(2,j))
                        if the_nonzero(1,j)==the_divisor(1,3)
                            third_konum=j;
                            break
                        end
                    end
                end
                
                if third_konum
                    count_frequency=count_frequency+1;
                    
                    the_nonzero(2,first_konum)=count_frequency;
                    the_nonzero(2,second_konum)=count_frequency;
                    the_nonzero(2,third_konum)=count_frequency;
                end
            end
        end
    end
end
