function anup_csa_algo (file_coef, the_choice)

%clear;

%file_coef=input('Enter the filename where the filter coefficients exist: ','s');
%the_choice=input('Choose the type of number representation: (0:binary, 1:CSD): ');

the_choice = str2num(the_choice);

initial_time=cputime;

file_name='';
dot_indis=length(file_coef);
for i=length(file_coef):-1:1
    if file_coef(1,i)=='.'
        dot_indis=i-1;
        break
    end
end
file_name=file_coef(1:1,1:dot_indis);

file_result=[file_name,'.result'];
fid_result=fopen(file_result,'w');

fprintf(fid_result,'* CSA Implementation of Constant Coefficients\n');
saat=clock;
fprintf(fid_result,'* Date: %s Time: %d:%d:%.0f \n',date,saat(1,4),saat(1,5),saat(1,6));
fprintf(fid_result,'* Coefficient File: %s\n',file_coef);

fprintf(fid_result,'\n');
fprintf(fid_result,'*** Implementation of Coefficients ***\n');
fprintf(fid_result,'\n');

say_list=0;
coef_list=[];
fid_coef=fopen(file_coef,'r');

while 1
    the_line=fgetl(fid_coef);
    if the_line==-1
        break
    else
        if not(isempty(the_line))
            the_number=str2num(char(the_line));
            if the_number~=0
                [power,posodd_number]=make_number_posodd(the_number);
                if not(posodd_number == 1)
                    if not(is_inside_coef(posodd_number,say_list,coef_list))
                        say_list=say_list+1;
                        coef_list(say_list,1)=posodd_number;
                    end
                end
                
                if the_number<0
                    fprintf(fid_result,'%d = -%d<<%d\n',the_number,posodd_number,power);
                else
                    fprintf(fid_result,'%d = +%d<<%d\n',the_number,posodd_number,power);
                end
            end
        end
    end
end

fclose(fid_coef);

say_imp=0;
the_imp=[];
the_partial=[];

say_divisors=0;
the_divisors=[];
the_frequency=[];

the_reps=cell(1,1);

for i=1:say_list
    if the_choice
        [say_instances,count_nonzero,cell_nonzero]=workon_csd_representation(coef_list(i,1));
    else
        [say_instances,count_nonzero,cell_nonzero]=workon_binary_representation(coef_list(i,1));
    end
    
    the_reps(i,1)=cell_nonzero;
    
    if count_nonzero>2
        coef_list(i,2)=0;
        [say_divisors,the_divisors,the_frequency]=find_nonoverlap_divisors(say_divisors,the_divisors,the_frequency,i,cell_nonzero{1,1});
    else
        coef_list(i,2)=1;
        say_imp=say_imp+1;
        the_imp(say_imp,:)=zeros(1,3);
        the_partial(say_imp,1)=coef_list(i,1);
        for j=1:count_nonzero
            the_imp(say_imp,j)=cell_nonzero{1,1}(1,j);
        end
    end
end

max_occur=1;
max_occur_index=0;

for i=1:say_divisors
    if the_frequency(i,1)>max_occur
        if self_test(the_divisors(i,:))
            max_occur=the_frequency(i,1);
            max_occur_index=i;
        end
    end
end

while max_occur_index
    say_imp=say_imp+1;
    for i=1:3
        the_imp(say_imp,i)=the_divisors(max_occur_index,i);
    end
    
    the_partial(say_imp,1)=find_partial_value(the_divisors(max_occur_index,:));
    [the_reps]=replace_divisor(max_occur_index,the_frequency,the_partial(say_imp,1),the_divisors(max_occur_index,:),the_reps);
    
    say_divisors=0;
    the_divisors=[];
    the_frequency=[];
    
    for i=1:say_list
        if not(coef_list(i,2))
            the_rep=the_reps{i,1};
            if length(the_rep)>2
                [say_divisors,the_divisors,the_frequency]=find_nonoverlap_divisors(say_divisors,the_divisors,the_frequency,i,the_rep);
            else
                coef_list(i,2)=1;
            end
        end
    end
    
    max_occur=1;
    max_occur_index=0;
    
    for i=1:say_divisors
        if the_frequency(i,1)>max_occur
            if self_test(the_divisors(i,:))
                max_occur=the_frequency(i,1);
                max_occur_index=i;
            end
        end
    end    
end

fprintf(fid_result,'\n');
fprintf(fid_result,'*** Implementation of Partial Terms ***\n');
fprintf(fid_result,'\n');

say_oper=0;
for i=1:say_imp
    no_oper=0;
    one_found=0;
    fprintf(fid_result,'S&C_%d =',the_partial(i,1));
    for j=1:3
        if the_imp(i,j)
            [power,posodd_number]=make_number_posodd(the_imp(i,j));
            
            if posodd_number==1
                if the_imp(i,j)<0
                    fprintf(fid_result,' -%d<<%d',posodd_number,power);
                else
                    fprintf(fid_result,' +%d<<%d',posodd_number,power);
                end
            else
                if not(one_found)
                    one_found=1;
                    if the_imp(i,j)<0
                        fprintf(fid_result,' -S_%d<<%d',posodd_number,power);
                    else
                        fprintf(fid_result,' +S_%d<<%d',posodd_number,power);
                    end
                else
                    if the_imp(i,j)<0
                        fprintf(fid_result,' -C_%d<<%d',posodd_number,power);
                    else
                        fprintf(fid_result,' +C_%d<<%d',posodd_number,power);
                    end
                end
            end
            
            the_imp(i,j)=posodd_number;
        else
            no_oper=1;
        end
    end
    
    fprintf(fid_result,'\n');
    
    if not(no_oper)
        say_oper=say_oper+1;
    end
end

say_34=0;
coef_34 = [];
partial_34 = {};

for i=1:say_list
    the_comb = the_reps{i,1};
    the_comb = determine_partials(the_comb);
    size_comb = size(the_comb);
    
    while (1)
        if size_comb(1,2) > 4
            [init_index, last_index] = find_index_34(size_comb(1,2), the_comb);
            
            the_coef = 0;
            for j=init_index:1:last_index
                if (or(the_comb(2,j) == 0, the_comb(2,j) == 1))
                    the_coef = the_coef + the_comb(1,j);
                end
            end
            
            if (where_is_partial(the_coef,say_34,coef_34) == 0)
                say_34=say_34+1;
                coef_34(say_34,1) = the_coef;
                partial_34{say_34,1} = the_comb(1,init_index:last_index);
            end
            the_comb = update_array_34(the_coef, init_index, last_index, the_comb);
            size_comb = size(the_comb);
        elseif (size_comb(1,2) == 3 | size_comb(1,2) == 4)
            say_34=say_34+1;
            coef_34(say_34,1)=coef_list(i,1);
            partial_34{say_34,1} = the_comb;
            break;
        else
            break;
        end
    end
end

for i=1:say_34
    the_34=partial_34{i,1};
    the_34=determine_partials(the_34);
    size_34=size(the_34);
    
    say_imp=say_imp+1;
    the_partial(say_imp,1)=coef_34(i,1);
    
    fprintf(fid_result,'S&C_%d =',coef_34(i,1));
    
    for j=1:size_34(1,2)
        [power,posodd_number]=make_number_posodd(the_34(1,j));
        the_imp(say_imp,j)=posodd_number;
        
        if the_34(1,j)<0
            if the_34(2,j)==1
                fprintf(fid_result,' -S_%d<<%d',posodd_number,power);
            elseif the_34(2,j)==2
                fprintf(fid_result,' -C_%d<<%d',posodd_number,power);
            else
                fprintf(fid_result,' -%d<<%d',posodd_number,power);
            end
        else
            if the_34(2,j)==1
                fprintf(fid_result,' +S_%d<<%d',posodd_number,power);
            elseif the_34(2,j)==2
                fprintf(fid_result,' +C_%d<<%d',posodd_number,power);
            else
                fprintf(fid_result,' +%d<<%d',posodd_number,power);
            end
        end
    end
    fprintf(fid_result,'\n');
    
    if (size_34(1,2) == 3)
        say_oper = say_oper + 1;
    else
        say_oper = say_oper + 2;
    end
end

[max_level]=find_level_new(say_imp,the_imp,the_partial);

fprintf(fid_result,'\n');
fprintf(fid_result,'Number of CSAs: %d\n',say_oper);
fprintf(fid_result,'Number of level: %d\n',max_level);
fprintf(fid_result,'Required CPU time: %.2f\n',cputime-initial_time);
fprintf(fid_result,'\n');

fclose(fid_result);

fprintf('[INFO] A solution with %d CSAs in %d adder-steps has just been obtained in %.2f seconds! \n', say_oper, max_level, cputime-initial_time);

function [init_index, last_index] = find_index_34 (the_col, the_array)

init_index = 0;
last_index = 0;

size_array=size(the_array);

for init_index=1:size_array(1,2)-2
    remain_3 = 0;
    remain_4 = 0;
    partial_3 = 0;
    partial_4 = 0;
    count_3 = zeros(1,3);
    count_4 = zeros(1,3);
    for i=0:1:3
        if (i<=2)
            if (the_array(2,init_index+i) == 1)
                remain_3 = remain_3 + the_array(1, init_index+i);
                partial_3 = partial_3 + the_array(1,init_index+i);
            elseif (the_array(2,init_index+i) == 2)
                remain_3 = remain_3 - the_array(1, init_index+i);
            else
                partial_3 = partial_3 + the_array(1,init_index+i);
            end
            count_3(1,the_array(2,init_index+i)+1) = count_3(1,the_array(2,init_index+i)+1) + 1;
        end
        
        if (init_index <= size_array(1,2)-3)
            if (the_array(2,init_index+i) == 1)
                remain_4 = remain_4 + the_array(1, init_index+i);
                partial_4 = partial_4 + the_array(1,init_index+i);
            elseif (the_array(2,init_index+i) == 2)
                remain_4 = remain_4 - the_array(1, init_index+i);
            else
                partial_4 = partial_4 + the_array(1,init_index+i);
            end
            count_4(1,the_array(2,init_index+i)+1) = count_4(1,the_array(2,init_index+i)+1) + 1;
        end
    end
    
    if (mod(partial_3,2) & remain_3 == 0)
        if (count_3(1,1) == 3)
            last_index = init_index + 2;
            break;
        elseif (count_3(1,1) == 1 & count_3(1,2) == 1 & count_3(1,3) == 1)
            last_index = init_index + 2;
            break
        end
    elseif (mod(partial_4,2) & remain_4 == 0)
        if (count_4(1,1) == 4)
            last_index = init_index + 3;
            break;
        elseif (count_4(1,1) == 2 & count_4(1,2) == 1 & count_4(1,3) == 1)
            last_index = init_index + 3;
            break;
        elseif (count_4(1,2) == 2 & count_4(1,3) == 2)
            last_index = init_index + 3;
            break;
        end
    end
end

function [an_array] = update_array_34 (the_coef, init_index, last_index, the_array)

say_term = 2;
an_array = [the_coef the_coef; 1 2];

for i = 1:length(the_array)
    if (or(i<init_index, i>last_index))
        say_term = say_term + 1;
        an_array(1, say_term) = the_array(1, i);
        an_array(2, say_term) = the_array(2, i);
    end
end
