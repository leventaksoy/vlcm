function [say_coefzero,cavm_sign,cavm_power,say_coef,coef_list,orig_coeflist,say_cons,cons_list,max_cons] = file_read_coef(file_coef, fid_result)

max_cons=0;
say_cons=1;
say_coef=0;
coef_list=[];
cavm_sign=-1;
cons_list=[1];
cavm_power=inf;
say_coefzero=0;
orig_coeflist=[];

fid_coef=fopen(file_coef,'r');

while 1
    the_line=fgetl(fid_coef);
    
    if the_line==-1
        break
    elseif isempty(the_line)
        break
    else
        the_coef=str2num(char(the_line));
        
        say_coef=say_coef+1;
        coef_list(say_coef,1)=the_coef;
        [coef_list(say_coef,3),coef_list(say_coef,4),coef_list(say_coef,2)]=make_number_posodd(the_coef);
        
        if the_coef
            if coef_list(say_coef,3)==1
                cavm_sign=1;
            end

            if coef_list(say_coef,4)<cavm_power
                cavm_power=coef_list(say_coef,4);
            end
            
            if ~is_inside_horizontal_array(say_cons,cons_list,coef_list(say_coef,2))
                say_cons=say_cons+1;
                cons_list(1,say_cons)=coef_list(say_coef,2);
                
                if coef_list(say_coef,2)>max_cons
                    max_cons=coef_list(say_coef,2);
                end
            end
            
            if the_coef<0
                fprintf(fid_result,'%6d = -%d<<%d\n',coef_list(say_coef,1),coef_list(say_coef,2),coef_list(say_coef,4));
            else
                fprintf(fid_result,'%6d = +%d<<%d\n',coef_list(say_coef,1),coef_list(say_coef,2),coef_list(say_coef,4));
            end
        else
            say_coefzero=say_coefzero+1;
            fprintf(fid_result,'%6d = 0<<0\n', the_coef);
        end
    end
end

orig_coeflist=coef_list(:,1);
coef_list(:,1)=(coef_list(:,1)*cavm_sign)/2^cavm_power;
coef_list(:,3)=coef_list(:,3)*cavm_sign;
coef_list(:,4)=coef_list(:,4)-cavm_power;

fclose(fid_coef);
