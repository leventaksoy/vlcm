function [say_divisors,the_divisors,the_frequency] = find_nonoverlap_divisors(say_divisors,the_divisors,the_frequency,the_index,the_nonzero)

say_divisor=0;
divisor_list=[];

the_length=length(the_nonzero);
the_initial=[1 2 3];
the_konum=3;

devam=1;
while devam
    for i=1:3
        a_divisor(1,i)=the_nonzero(1,the_initial(1,i));
    end
    
    [is_neg,the_power,a_divisor]=make_divisor_posodd(a_divisor);
    
    if not(is_divisor_inside(say_divisor,divisor_list,a_divisor))
        say_divisor=say_divisor+1;
        divisor_list(say_divisor,:)=a_divisor;
        
        count_frequency=find_frequency(the_length,the_nonzero,the_initial,a_divisor);
        the_pos=where_is_divisor(say_divisors,the_divisors,a_divisor);
        
        if not(the_pos)
            say_divisors=say_divisors+1;
            the_frequency(say_divisors,1)=0;
            the_divisors(say_divisors,:)=a_divisor;
            the_pos=say_divisors;
        end
        
        for i=1:count_frequency
            the_frequency(the_pos,1)=the_frequency(the_pos,1)+1;
            the_frequency(the_pos,the_frequency(the_pos,1)+1)=the_index;
        end
    end
    
    if the_initial(1,the_konum)~=the_length
        the_initial(1,the_konum)=the_initial(1,the_konum)+1;
    else
        while 1
            the_konum=the_konum-1;
            
            if not(the_konum)
                devam=0;
                break
            end
            
            if the_initial(1,the_konum)~=the_length+the_konum-3
                break
            end
        end
        
        if devam
            the_initial(1,the_konum)=the_initial(1,the_konum)+1;
            
            for i=the_konum+1:1:3
                the_initial(1,i)=the_initial(1,i-1)+1;
            end
            the_konum=3;
        end
    end
    
end