function [is_neg,the_power,a_divisor] = make_divisor_posodd(a_divisor)

is_neg=0;

if a_divisor(1,length(a_divisor))<0
    is_neg=1;
    a_divisor=(-1)*a_divisor;
end

the_power=0;

while 1
    is_odd=0;
    
    for i=1:3
        if mod(a_divisor(1,i),2)
            is_odd=1;
            return
        end
    end
    
    if not(is_odd)
        the_power=the_power+1;
        a_divisor=a_divisor/2;
    end
end