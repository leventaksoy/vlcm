function [is_synth] = sarcastic_find_optimal_wod(bit_width,say_imp,imp_list,say_unimp,unimp_list)

is_synth=0;

for i=1:say_unimp
    digit_unimp=ceil(log2(unimp_list(1,i)));

    for j=1:say_imp
        digit_imp=ceil(log2(imp_list(1,j)));

        for us=0:1:bit_width+1
            the_partial=(2^us)*imp_list(1,j)-unimp_list(1,i);
            [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);

            if is_inside(posodd_partial,say_imp,imp_list)
                is_synth=1;
            end

            if not(is_synth)
                the_partial=(2^us)*imp_list(1,j)+unimp_list(1,i);
                [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);

                if is_inside(posodd_partial,say_imp,imp_list)
                    is_synth=1;
                end
            end

            if is_synth
                break
            end
        end

%         if not(is_synth)
%             for us=1:1:bit_width-digit_unimp+1
%                 the_partial=imp_list(1,j)-(2^us)*unimp_list(1,i);
%                 [the_power,posodd_partial]=make_number_posodd(the_partial);
% 
%                 if is_inside(posodd_partial,say_imp,imp_list)
%                     is_synth=1;
%                 end
% 
%                 if not(is_synth)
%                     the_partial=imp_list(1,j)+(2^us)*unimp_list(1,i);
% 
%                     if is_inside(the_partial,say_imp,imp_list)
%                         is_synth=1;
%                     end
%                 end
% 
%                 if is_synth
%                     break
%                 end
%             end
%         end

        if is_synth
            break
        end
    end
end
