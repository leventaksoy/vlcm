function mcm_algo (source_file, the_aim, dfs_time)

%area_delay=input('Design objective (0: area, 1: delay): ');
dfs_cpu_limit=str2num(dfs_time);
the_aim=str2num(the_aim);
initial_time=cputime;

file_name='';
dot_indis=length(source_file);
for i=length(source_file):-1:1
    if source_file(1,i)=='.'
        dot_indis=i-1;
        break
    end
end
file_name=source_file(1:1,1:dot_indis);

file_result=[file_name,'.result'];
fid_result=fopen(file_result,'w');

fprintf(fid_result,'* Shift-Adds Implementation of Multiple Constant Multiplications\n');
saat=clock;
fprintf(fid_result,'* Date: %s Time: %d:%d:%.0f \n',date,saat(1,4),saat(1,5),saat(1,6));
fprintf(fid_result,'* Coefficient File: %s\n',source_file);
fprintf(fid_result,'\n');
fprintf(fid_result,'*** Implementation of Coefficients ***\n');
fprintf(fid_result,'\n');

[say_coefzero,output_sign,output_power,say_coef,coef_list,orig_coeflist,say_cons,cons_list,max_cons]=file_read_coef(source_file, fid_result);
if the_aim
    [max_step,say_oper,oper_list,oper_indis]=find_mcm_solution_wdc(say_cons,cons_list,max_cons);
else
    [max_step,say_oper,oper_list,oper_indis]=find_mcm_solution_wodc(dfs_cpu_limit,say_cons,cons_list,max_cons);
end

fprintf(fid_result,'\n');
fprintf(fid_result,'*** Implementation of Partial Terms ***\n');
fprintf(fid_result,'\n');

for i=1:say_oper
    fprintf(fid_result,'%6d>>%d = ',oper_list(i,1),oper_list(i,2));
    if oper_list(i,3) == 1
        fprintf(fid_result,'+%d<<%d ',oper_list(i,4),oper_list(i,5));
    else
        fprintf(fid_result,'-%d<<%d ',oper_list(i,4),oper_list(i,5));
    end
    if oper_list(i,6) == 1
        fprintf(fid_result,'+%d<<%d\n',oper_list(i,7),oper_list(i,8));
    else
        fprintf(fid_result,'-%d<<%d\n',oper_list(i,7),oper_list(i,8));
    end
end

last_time=cputime-initial_time;

fprintf(fid_result,'\n');
fprintf(fid_result,'* Number of operations: %d\n',say_oper);
fprintf(fid_result,'* Number of adder-steps: %d\n',max_step);
fprintf(fid_result,'* Required CPU time to find the solution: %.2f\n',last_time);
fprintf(fid_result,'\n');

fprintf('[INFO] A solution with %d operations in %d adder-steps is obtained in %.2f seconds! \n',say_oper, max_step, last_time);

fclose(fid_result);

