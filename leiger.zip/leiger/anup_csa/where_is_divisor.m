function the_pos = where_is_divisor(say_divisors,the_divisors,a_divisor)

the_pos=0;

for i=1:say_divisors
    value=1;
    
    for j=1:3
        if a_divisor(1,j)~=the_divisors(i,j)
            value=0;
            break
        end
    end
    
    if value
        the_pos=i;
        break
    end
end