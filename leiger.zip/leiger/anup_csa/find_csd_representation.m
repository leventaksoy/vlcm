function [say_nonzeros,non_zeros] = find_csd_representation(the_number)

is_neg=0;

if the_number<0
    is_neg=1;
    the_number=(-1)*the_number;
end

[say_digit,csd_rep]=find_binary_representation(the_number);

say_one=0;
start_one=0;
for h=1:say_digit
    if csd_rep(1,h)==0
        if and(start_one~=0,say_one>1)
            for i=start_one:1:h
                if i==start_one
                    csd_rep(1,i)=-1;
                elseif i==h
                    csd_rep(1,i)=1;
                else
                    csd_rep(1,i)=0;
                end
            end
            say_one=1;
            start_one=h;
        else
            say_one=0;
            start_one=0;
        end
    else
        if start_one==0
            say_one=1;
            start_one=h;
        else
            say_one=say_one+1;
        end
    end
end

non_zeros=[];
say_nonzeros=0;
if is_neg==1
    for i=1:say_digit
        if csd_rep(1,i)==1
            say_nonzeros=say_nonzeros+1;
            non_zeros(1,say_nonzeros)=(-1)*(2^(i-1));
        elseif csd_rep(1,i)==-1
            say_nonzeros=say_nonzeros+1;
            non_zeros(1,say_nonzeros)=2^(i-1);
        end
    end
else
    for i=1:say_digit
        if csd_rep(1,i)==1
            say_nonzeros=say_nonzeros+1;
            non_zeros(1,say_nonzeros)=2^(i-1);
        elseif csd_rep(1,i)==-1
            say_nonzeros=say_nonzeros+1;
            non_zeros(1,say_nonzeros)=(-1)*(2^(i-1));
        end
    end
end
