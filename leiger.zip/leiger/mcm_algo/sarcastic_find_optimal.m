function [say_imp,imp_list,say_unimp,unimp_list] = sarcastic_find_optimal(bit_width,max_level,constant_levels,say_imp,imp_list,say_unimp,unimp_list)

while 1
    say_add=0;
    add_list=[];
    
    for i=1:say_unimp
        unimp_level=constant_levels((unimp_list(1,i)+1)/2,1);
        
        if unimp_level==1
            say_add=say_add+1;
            add_list(1,say_add)=i;
            add_list(2,say_add)=1;
        elseif sarcastic_checkif_lowlevels(unimp_level,say_imp,imp_list)
            is_synth=0;
            digit_unimp=ceil(log2(unimp_list(1,i)));
        
            for j=1:say_imp
                digit_imp=ceil(log2(imp_list(1,j)));

                for us=0:1:bit_width+1
                    the_partial=(2^us)*imp_list(1,j)-unimp_list(1,i);
                    [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);

                    [the_pos]=where_is_inside(posodd_partial,say_imp,imp_list);
                    if the_pos
                        imp_level=max(imp_list(2,the_pos),imp_list(2,j))+1;
                        if imp_level<=max_level
                            is_synth=1;
                            say_add=say_add+1;
                            add_list(1,say_add)=i;
                            add_list(2,say_add)=imp_level;
                        end
                    end

                    if not(is_synth)
                        the_partial=(2^us)*imp_list(1,j)+unimp_list(1,i);
                        [the_sign,the_power,posodd_partial]=make_number_posodd(the_partial);

                        [the_pos]=where_is_inside(posodd_partial,say_imp,imp_list);
                        if the_pos
                            imp_level=max(imp_list(2,the_pos),imp_list(2,j))+1;
                            if imp_level<=max_level
                                is_synth=1;
                                say_add=say_add+1;
                                add_list(1,say_add)=i;
                                add_list(2,say_add)=imp_level;
                            end
                        end
                    end

                    if is_synth
                        break
                    end
                end

%                 if not(is_synth)
%                     for us=1:1:bit_width-digit_unimp+1
%                         the_partial=imp_list(1,j)-(2^us)*unimp_list(1,i);
%                         [the_power,posodd_partial]=make_number_posodd(the_partial);
% 
%                         [the_pos]=whereis_inside(posodd_partial,say_imp,imp_list);
%                         if the_pos
%                             imp_level=max(imp_list(2,the_pos),imp_list(2,j))+1;
%                             if imp_level<=max_level
%                                 is_synth=1;
%                                 say_add=say_add+1;
%                                 add_list(1,say_add)=i;
%                                 add_list(2,say_add)=imp_level;
%                             end
%                         end
% 
%                         if not(is_synth)
%                             the_partial=imp_list(1,j)+(2^us)*unimp_list(1,i);
% 
%                             [the_pos]=whereis_inside(the_partial,say_imp,imp_list);
%                             if the_pos
%                                 imp_level=max(imp_list(2,the_pos),imp_list(2,j))+1;
%                                 if imp_level<=max_level
%                                     is_synth=1;
%                                     say_add=say_add+1;
%                                     add_list(1,say_add)=i;
%                                     add_list(2,say_add)=imp_level;
%                                 end
%                             end
%                         end
% 
%                         if is_synth
%                             break
%                         end
%                     end
%                 end

                if is_synth
                    break
                end
            end
        end
    end
    
    if say_add
        for i=1:say_add
            say_imp=say_imp+1;
            imp_list(1,say_imp)=unimp_list(1,add_list(1,i)-i+1);
            imp_list(2,say_imp)=add_list(2,i);
            
            say_unimp=say_unimp-1;
            unimp_list(:,add_list(1,i)-i+1)=[];
        end
    else
        break
    end
end
