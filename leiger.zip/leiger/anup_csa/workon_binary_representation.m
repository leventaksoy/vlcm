function [say_instances,count_nonzero,cell_nonzero] = workon_binary_representation(the_number)

non_zero=[];
say_nonzero=0;

say_instances=0;
count_nonzero=[];
cell_nonzero=cell(1,1);

if the_number~=0
    say_digit=0;
    while the_number~=1
        say_digit=say_digit+1;
        remainder=mod(the_number,2);
        if remainder==0
            the_number=the_number/2;
        else
            the_number=(the_number-1)/2;
            say_nonzero=say_nonzero+1;
            non_zero(1,say_nonzero)=2^(say_digit-1);
        end
    end
    
    say_nonzero=say_nonzero+1;
    non_zero(1,say_nonzero)=2^(say_digit);
    
    say_instances=say_instances+1;
    count_nonzero(say_instances,1)=say_nonzero;
    cell_nonzero{say_instances,1}=non_zero;
else
    say_instances=say_instances+1;
    count_nonzero(say_instances,1)=0;
    cell_nonzero{say_instances,1}=0;
end
